"""Green Gate commercial - shared Blender library.

Real-world scale (metres). Products are built standing on z=0 facing -Y.
Works with Blender 4.5 LTS (Colab / cloud) and 5.x (local preview).
"""
import bpy, bmesh, math, os
from mathutils import Vector, Matrix, Euler

ASSET_DIR = os.path.dirname(os.path.abspath(__file__))
TAU = math.tau


def tex_path(name):
    return os.path.join(ASSET_DIR, 'tex', name)


def screen_path(name):
    return os.path.join(ASSET_DIR, 'screens', name)


# ----------------------------------------------------------------- colour utils
def srgb_to_lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hexc(h, a=1.0):
    h = h.lstrip('#')
    return tuple(srgb_to_lin(int(h[i:i + 2], 16) / 255) for i in (0, 2, 4)) + (a,)


GREEN = hexc('#219046')
GREEN_DEEP = hexc('#14552a')


# ----------------------------------------------------------------- scene utils
def clear_scene():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.curves, bpy.data.lights,
                 bpy.data.cameras, bpy.data.images, bpy.data.node_groups):
        for d in list(coll):
            if d.users == 0:
                coll.remove(d)
    for c in list(bpy.data.collections):
        bpy.data.collections.remove(c)


def collection(name, parent=None):
    c = bpy.data.collections.get(name)
    if not c:
        c = bpy.data.collections.new(name)
        (parent or bpy.context.scene.collection).children.link(c)
    return c


_ACTIVE_COLL = [None]


def set_collection(c):
    _ACTIVE_COLL[0] = c


def link(o):
    (_ACTIVE_COLL[0] or bpy.context.scene.collection).objects.link(o)
    return o


def empty(name, loc=(0, 0, 0), parent=None):
    e = bpy.data.objects.new(name, None)
    e.empty_display_size = 0.02
    e.location = loc
    link(e)
    if parent:
        e.parent = parent
    return e


def mesh_obj(name, bm, mat=None, parent=None, smooth=True):
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    if smooth:
        try:
            me.shade_smooth()
        except AttributeError:
            me.polygons.foreach_set('use_smooth', [True] * len(me.polygons))
    o = bpy.data.objects.new(name, me)
    link(o)
    if mat:
        me.materials.append(mat)
    if parent:
        o.parent = parent
    return o


def mod_bevel(o, width, segments=3, angle=35, profile=0.5, harden=False, limit='ANGLE'):
    m = o.modifiers.new('Bevel', 'BEVEL')
    m.width = width
    m.segments = segments
    m.limit_method = limit
    if limit == 'ANGLE':
        m.angle_limit = math.radians(angle)
    m.profile = profile
    m.harden_normals = harden
    m.use_clamp_overlap = True
    return m


def mod_subsurf(o, levels=2, render=None):
    m = o.modifiers.new('Subd', 'SUBSURF')
    m.levels = levels
    m.render_levels = render if render is not None else levels
    return m


def mod_wnormal(o):
    m = o.modifiers.new('WNormal', 'WEIGHTED_NORMAL')
    m.keep_sharp = True
    return m


def mod_solidify(o, t, offset=-1):
    m = o.modifiers.new('Solid', 'SOLIDIFY')
    m.thickness = t
    m.offset = offset
    m.use_even_offset = True
    return m


# ----------------------------------------------------------------- geometry
def rounded_rect(w, h, r, seg=10):
    """2D points (ccw) of a rounded rectangle centred at origin."""
    r = min(r, w / 2, h / 2)
    pts = []
    corners = [(w / 2 - r, h / 2 - r, 0), (-w / 2 + r, h / 2 - r, 90),
               (-w / 2 + r, -h / 2 + r, 180), (w / 2 - r, -h / 2 + r, 270)]
    for cx, cy, a0 in corners:
        for i in range(seg + 1):
            a = math.radians(a0 + 90 * i / seg)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def squircle(a, b, n=4.0, count=96, skew=0.0):
    pts = []
    for i in range(count):
        t = TAU * i / count
        c, s = math.cos(t), math.sin(t)
        x = a * math.copysign(abs(c) ** (2 / n), c)
        y = b * math.copysign(abs(s) ** (2 / n), s)
        x *= 1 + skew * (y / b)
        pts.append((x, y))
    return pts


def bm_prism(pts2d, depth, plane='XZ', z0=None):
    """Extrude a closed 2D outline into a prism. plane 'XZ' extrudes along Y
    (front face at -depth/2), 'XY' extrudes along Z from 0 to depth."""
    bm = bmesh.new()
    if plane == 'XZ':
        front = [bm.verts.new((x, -depth / 2, y)) for x, y in pts2d]
        back = [bm.verts.new((x, depth / 2, y)) for x, y in pts2d]
    else:
        zb = 0 if z0 is None else z0
        front = [bm.verts.new((x, y, zb)) for x, y in pts2d]
        back = [bm.verts.new((x, y, zb + depth)) for x, y in pts2d]
    n = len(pts2d)
    f1 = bm.faces.new(list(reversed(front)) if plane == 'XY' else front)
    f2 = bm.faces.new(back if plane == 'XY' else list(reversed(back)))
    for i in range(n):
        j = (i + 1) % n
        bm.faces.new((front[i], front[j], back[j], back[i]) if plane == 'XY' else
                     (front[j], front[i], back[i], back[j]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def bm_lathe(profile, seg=96, closed_axis=True, uv_label=None):
    """Revolve (r, z) profile around Z. Profile points ordered; points with r==0
    collapse to the axis. Returns bmesh with UVs (u=angle, v=normalised z)."""
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new('UVMap')
    rings = []
    zs = [p[1] for p in profile]
    zmin, zmax = min(zs), max(zs)
    for r, z in profile:
        if r < 1e-7:
            rings.append([bm.verts.new((0, 0, z))])
        else:
            rings.append([bm.verts.new((r * math.cos(TAU * i / seg), r * math.sin(TAU * i / seg), z))
                          for i in range(seg)])
    for a, b in zip(rings[:-1], rings[1:]):
        if len(a) == 1 and len(b) == 1:
            continue
        for i in range(seg):
            j = (i + 1) % seg
            if len(a) == 1:
                vs = (a[0], b[i], b[j])
            elif len(b) == 1:
                vs = (a[j], a[i], b[0])
            else:
                vs = (a[i], a[j], b[j], b[i])
            try:
                f = bm.faces.new(vs)
            except ValueError:
                continue
            for lp in f.loops:
                co = lp.vert.co
                nxt = (len(a) > 1 and lp.vert is a[j]) or (len(b) > 1 and lp.vert is b[j])
                lp[uv].uv = ((i + (1 if nxt else 0)) / seg, (co.z - zmin) / max(zmax - zmin, 1e-6))
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-7)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def lathe_obj(name, profile, mat=None, parent=None, seg=96, subd=0):
    o = mesh_obj(name, bm_lathe(profile, seg), mat, parent)
    if subd:
        mod_subsurf(o, subd)
    return o


def cylinder_band(name, r, z0, z1, a0, a1, mat, parent=None, seg=64):
    """Curved label patch on a cylinder (angles in radians, -Y is angle -pi/2)."""
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new('UVMap')
    cols = []
    for i in range(seg + 1):
        a = a0 + (a1 - a0) * i / seg
        cols.append((bm.verts.new((r * math.cos(a), r * math.sin(a), z0)),
                     bm.verts.new((r * math.cos(a), r * math.sin(a), z1)), i / seg))
    for (b0, t0, u0), (b1, t1, u1) in zip(cols[:-1], cols[1:]):
        f = bm.faces.new((b0, t0, t1, b1))
        for lp, uvv in zip(f.loops, ((u0, 0), (u0, 1), (u1, 1), (u1, 0))):
            lp[uv].uv = uvv
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        c = f.calc_center_median()
        if f.normal.dot(Vector((c.x, c.y, 0))) < 0:
            f.normal_flip()
    return mesh_obj(name, bm, mat, parent)


def plane_obj(name, w, h, mat=None, parent=None, plane='XZ', subdiv=0):
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new('UVMap')
    if plane == 'XZ':
        vs = [bm.verts.new(p) for p in ((-w / 2, 0, -h / 2), (w / 2, 0, -h / 2), (w / 2, 0, h / 2), (-w / 2, 0, h / 2))]
    else:
        vs = [bm.verts.new(p) for p in ((-w / 2, -h / 2, 0), (w / 2, -h / 2, 0), (w / 2, h / 2, 0), (-w / 2, h / 2, 0))]
    f = bm.faces.new(vs)
    for lp, uvv in zip(f.loops, ((0, 0), (1, 0), (1, 1), (0, 1))):
        lp[uv].uv = uvv
    if plane == 'XZ':
        f.normal_update()
        if f.normal.y > 0:
            f.normal_flip()
    if subdiv:
        bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=subdiv, use_grid_fill=True)
    return mesh_obj(name, bm, mat, parent, smooth=False)


def box_obj(name, sx, sy, sz, mat=None, parent=None, bevel=0.0, seg=3, loc=(0, 0, 0)):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=(sx, sy, sz), verts=bm.verts)
    bmesh.ops.translate(bm, vec=loc, verts=bm.verts)
    o = mesh_obj(name, bm, mat, parent, smooth=bevel > 0)
    if bevel > 0:
        mod_bevel(o, bevel, seg, harden=True)
    return o


def cyl_obj(name, r, h, mat=None, parent=None, seg=64, loc=(0, 0, 0), bevel=0.0, axis='Z'):
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r, radius2=r, depth=h)
    if axis == 'X':
        bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2, 3, 'Y'))
    elif axis == 'Y':
        bmesh.ops.rotate(bm, verts=bm.verts, cent=(0, 0, 0), matrix=Matrix.Rotation(math.pi / 2, 3, 'X'))
    bmesh.ops.translate(bm, vec=loc, verts=bm.verts)
    o = mesh_obj(name, bm, mat, parent)
    if bevel > 0:
        mod_bevel(o, bevel, 3, angle=50, harden=True)
    return o


def rounded_slab(name, w, h, depth, r, edge, mat=None, parent=None, seg=12, edge_seg=5, plane='XZ'):
    """Rounded-rect prism with rounded edges (phone body, glass, cases)."""
    o = mesh_obj(name, bm_prism(rounded_rect(w, h, r, seg), depth, plane), mat, parent)
    if edge > 0:
        mod_bevel(o, edge, edge_seg, angle=60, harden=True)
    return o


def sweep_rect(path_pts, width, thick, closed=False, corner=0.35, side=(1, 0, 0)):
    """Sweep a rounded-rect cross-section (width along local X, thickness along
    the path normal) along a 3D polyline. Returns bmesh."""
    bm = bmesh.new()
    sec = rounded_rect(width, thick, thick * corner, 3)
    n = len(path_pts)
    rings = []
    for i, p in enumerate(path_pts):
        p = Vector(p)
        a = Vector(path_pts[max(i - 1, 0)]) if not closed else Vector(path_pts[(i - 1) % n])
        b = Vector(path_pts[min(i + 1, n - 1)]) if not closed else Vector(path_pts[(i + 1) % n])
        t = (b - a).normalized()
        sd = Vector(side)
        nrm = t.cross(sd).normalized()
        sd = nrm.cross(t).normalized()
        rings.append([bm.verts.new(p + sd * sx + nrm * sy) for sx, sy in sec])
    m = len(sec)
    rng = range(n) if closed else range(n - 1)
    for i in rng:
        A, B = rings[i], rings[(i + 1) % n]
        for k in range(m):
            kk = (k + 1) % m
            bm.faces.new((A[k], A[kk], B[kk], B[k]))
    if not closed:
        bm.faces.new(list(reversed(rings[0])))
        bm.faces.new(rings[-1])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


# ----------------------------------------------------------------- materials
def _nt(mat):
    mat.use_nodes = True
    nt = mat.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.location = (600, 0)
    return nt, out


def _set(node, name, val):
    if name in node.inputs:
        node.inputs[name].default_value = val


def principled(name, base=(0.8, 0.8, 0.8, 1), metal=0.0, rough=0.5, **kw):
    mat = bpy.data.materials.new(name)
    nt, out = _nt(mat)
    p = nt.nodes.new('ShaderNodeBsdfPrincipled')
    _set(p, 'Base Color', base)
    _set(p, 'Metallic', metal)
    _set(p, 'Roughness', rough)
    mapping = {'ior': 'IOR', 'transmission': 'Transmission Weight', 'coat': 'Coat Weight',
               'coat_rough': 'Coat Roughness', 'aniso': 'Anisotropic', 'aniso_rot': 'Anisotropic Rotation',
               'sss': 'Subsurface Weight', 'sss_scale': 'Subsurface Scale', 'sheen': 'Sheen Weight',
               'spec': 'Specular IOR Level', 'film': 'Thin Film Thickness', 'film_ior': 'Thin Film IOR',
               'emit_strength': 'Emission Strength', 'alpha': 'Alpha', 'coat_tint': 'Coat Tint'}
    for k, v in kw.items():
        if k in mapping:
            _set(p, mapping[k], v)
        elif k == 'sss_radius':
            _set(p, 'Subsurface Radius', v)
        elif k == 'emit':
            _set(p, 'Emission Color', v)
    nt.links.new(p.outputs[0], out.inputs[0])
    mat['bsdf'] = p.name
    return mat


def bsdf(mat):
    return mat.node_tree.nodes[mat.get('bsdf', 'Principled BSDF')]


def add_noise_rough(mat, base_rough, amount=0.08, scale=60.0, detail=6.0, stretch=None):
    """Micro roughness variation (smudges / tooling) - key for non-CG look."""
    nt = mat.node_tree
    p = bsdf(mat)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    if stretch:
        mp.inputs['Scale'].default_value = stretch
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = scale
    nz.inputs['Detail'].default_value = detail
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['To Min'].default_value = max(base_rough - amount, 0.0)
    mr.inputs['To Max'].default_value = min(base_rough + amount, 1.0)
    mr.inputs['From Min'].default_value = 0.3
    mr.inputs['From Max'].default_value = 0.7
    nt.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], nz.inputs['Vector'])
    nt.links.new(nz.outputs['Fac'], mr.inputs['Value'])
    nt.links.new(mr.outputs['Result'], p.inputs['Roughness'])
    return mat


def add_bump(mat, strength=0.05, scale=200.0, detail=4.0, kind='noise', stretch=None, distance=0.0005):
    nt = mat.node_tree
    p = bsdf(mat)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    if stretch:
        mp.inputs['Scale'].default_value = stretch
    if kind == 'voronoi':
        tx = nt.nodes.new('ShaderNodeTexVoronoi')
        tx.inputs['Scale'].default_value = scale
        outname = 'Distance'
    else:
        tx = nt.nodes.new('ShaderNodeTexNoise')
        tx.inputs['Scale'].default_value = scale
        tx.inputs['Detail'].default_value = detail
        outname = 'Fac'
    bp = nt.nodes.new('ShaderNodeBump')
    bp.inputs['Strength'].default_value = strength
    bp.inputs['Distance'].default_value = distance
    nt.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], tx.inputs['Vector'])
    nt.links.new(tx.outputs[outname], bp.inputs['Height'])
    nt.links.new(bp.outputs['Normal'], p.inputs['Normal'])
    return mat


def image_node(nt, path, colorspace='sRGB', extension='REPEAT', interp='Cubic'):
    if os.path.exists(path):
        img = bpy.data.images.load(path, check_existing=True)
    else:  # keep building if an asset is missing (logged, shows as flat grey)
        print('MISSING_ASSET', path)
        img = bpy.data.images.get('missing_' + os.path.basename(path)) or             bpy.data.images.new('missing_' + os.path.basename(path), 4, 4, alpha=True)
    try:
        img.colorspace_settings.name = colorspace
    except TypeError:
        pass
    n = nt.nodes.new('ShaderNodeTexImage')
    n.image = img
    n.extension = extension
    n.interpolation = interp
    return n


def mat_label(name, img, rough=0.55, alpha=False, sss=0.0, scale=None):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    mat = principled(name, rough=rough, sss=sss, sss_scale=0.001)
    nt = mat.node_tree
    p = bsdf(mat)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    t = image_node(nt, tex_path(img), extension='CLIP' if alpha else 'REPEAT')
    if scale:
        mp = nt.nodes.new('ShaderNodeMapping')
        mp.inputs['Scale'].default_value = scale
        nt.links.new(tc.outputs['UV'], mp.inputs['Vector'])
        nt.links.new(mp.outputs[0], t.inputs['Vector'])
    else:
        nt.links.new(tc.outputs['UV'], t.inputs['Vector'])
    nt.links.new(t.outputs['Color'], p.inputs['Base Color'])
    if alpha:
        nt.links.new(t.outputs['Alpha'], p.inputs['Alpha'])
        try:
            mat.blend_method = 'HASHED'
        except Exception:
            pass
    add_bump(mat, 0.08, 400, 3)
    return mat


def mat_glass(name, color=(1, 1, 1, 1), rough=0.0, ior=1.5, film=0.0):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, rough=rough, ior=ior, transmission=1.0, film=film)
    return m


def mat_metal(name, color, rough=0.15, aniso=0.0, brushed=False):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, metal=1.0, rough=rough, aniso=aniso)
    if brushed:
        add_noise_rough(m, rough, 0.06, scale=180, detail=8, stretch=(1, 1, 40))
    else:
        add_noise_rough(m, rough, 0.03, scale=30, detail=4)
    return m


def mat_radial_brushed(name, color, rough=0.25, aniso=0.75):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, metal=1.0, rough=rough, aniso=aniso)
    nt = m.node_tree
    tg = nt.nodes.new('ShaderNodeTangent')
    tg.direction_type = 'RADIAL'
    tg.axis = 'Z'
    nt.links.new(tg.outputs[0], bsdf(m).inputs['Tangent'])
    return m


def mat_tortoise(name):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, rough=0.22, coat=1.0, coat_rough=0.03, sss=0.25, sss_scale=0.002)
    nt = m.node_tree
    p = bsdf(m)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    mp.inputs['Scale'].default_value = (1, 1, 2.5)
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 90
    nz.inputs['Detail'].default_value = 3
    nz.inputs['Distortion'].default_value = 0.6
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    el = ramp.color_ramp.elements
    el[0].position, el[0].color = 0.40, hexc('#120904')
    el[1].position, el[1].color = 0.66, hexc('#a5571b')
    e = el.new(0.53)
    e.color = hexc('#3d1c08')
    nt.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], nz.inputs['Vector'])
    nt.links.new(nz.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], p.inputs['Base Color'])
    return m


def mat_cardboard(name):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, rough=0.82)
    nt = m.node_tree
    p = bsdf(m)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    nz = nt.nodes.new('ShaderNodeTexNoise')
    nz.inputs['Scale'].default_value = 35
    nz.inputs['Detail'].default_value = 10
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].color = hexc('#9c7349')
    ramp.color_ramp.elements[1].color = hexc('#c29a6b')
    nt.links.new(tc.outputs['Object'], nz.inputs['Vector'])
    nt.links.new(nz.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], p.inputs['Base Color'])
    add_bump(m, 0.12, 600, 6)
    return m


def mat_paper(name, color, rough=0.62, bump=0.1):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, rough=rough, sheen=0.04)
    add_bump(m, bump, 300, 8)
    return m


def mat_plaster(name, color, rough=0.75):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, rough=rough)
    add_bump(m, 0.06, 140, 6)
    return m


def mat_floor(name, color, rough=0.2, var=0.06):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    m = principled(name, base=color, rough=rough, spec=0.6)
    add_noise_rough(m, rough, var, scale=6, detail=8)
    return m


def mat_backdrop(name, color, rough=0.9):
    if name in bpy.data.materials:
        return bpy.data.materials[name]
    return principled(name, base=color, rough=rough, spec=0.25)


def mat_emission(name, color, strength):
    mat = bpy.data.materials.new(name)
    nt, out = _nt(mat)
    e = nt.nodes.new('ShaderNodeEmission')
    e.inputs['Color'].default_value = color
    e.inputs['Strength'].default_value = strength
    nt.links.new(e.outputs[0], out.inputs[0])
    return mat


# ----------------------------------------------------------------- lights / camera
def area_light(name, loc, target, size=(1, 1), energy=100, color=(1, 1, 1), shape='RECTANGLE', spread=180,
               parent=None, visible_camera=False):
    ld = bpy.data.lights.new(name, 'AREA')
    ld.shape = shape
    ld.size = size[0]
    ld.size_y = size[1]
    ld.energy = energy
    ld.color = color[:3]
    ld.spread = math.radians(spread)
    o = bpy.data.objects.new(name, ld)
    link(o)
    o.location = loc
    aim(o, target)
    if parent:
        o.parent = parent
    try:
        o.visible_camera = visible_camera
    except AttributeError:
        pass
    return o


def area_light_irr(name, loc, target, size=(1, 1), irradiance=3.0, **kw):
    """Area light whose power gives ~`irradiance` W/m^2 at the target
    (a white diffuse surface reads ~0.8 * irradiance / pi)."""
    d = (Vector(target) - Vector(loc)).length
    return area_light(name, loc, target, size, energy=irradiance * math.pi * d * d, **kw)


def point_light(name, loc, energy=10, radius=0.05, color=(1, 1, 1)):
    ld = bpy.data.lights.new(name, 'POINT')
    ld.energy = energy
    ld.shadow_soft_size = radius
    ld.color = color[:3]
    o = bpy.data.objects.new(name, ld)
    link(o)
    o.location = loc
    return o


def aim(o, target):
    d = Vector(target) - Vector(o.location)
    o.rotation_mode = 'XYZ'
    o.rotation_euler = d.to_track_quat('-Z', 'Y').to_euler()


def camera(name, loc, target, lens=50, fstop=4.0, focus=None, sensor=36):
    cd = bpy.data.cameras.new(name)
    cd.lens = lens
    cd.sensor_width = sensor
    cd.dof.use_dof = fstop is not None
    if fstop:
        cd.dof.aperture_fstop = fstop
        cd.dof.aperture_blades = 9
        cd.dof.aperture_rotation = math.radians(10)
    o = bpy.data.objects.new(name, cd)
    link(o)
    o.location = loc
    aim(o, target)
    if focus is not None:
        if isinstance(focus, bpy.types.Object):
            cd.dof.focus_object = focus
        else:
            cd.dof.focus_distance = focus
    return o


# ----------------------------------------------------------------- studio
def cyclorama(name, color, size=6.0, height=3.0, radius=0.8, rough=0.85, mat=None, parent=None, loc=(0, 0, 0)):
    """Seamless floor-to-wall backdrop. Floor extends toward -Y, wall at +Y."""
    bm = bmesh.new()
    steps = 16
    prof = [(-size / 2, 0.0)] + [(size / 2 - radius + radius * math.sin(math.pi / 2 * i / steps),
                                   radius - radius * math.cos(math.pi / 2 * i / steps)) for i in range(steps + 1)]
    prof.append((size / 2, height))
    cols = []
    for x in (-size, size):
        cols.append([bm.verts.new((x, y, z)) for y, z in prof])
    for k in range(len(prof) - 1):
        bm.faces.new((cols[0][k], cols[1][k], cols[1][k + 1], cols[0][k + 1]))
    bmesh.ops.subdivide_edges(bm, edges=[e for e in bm.edges if abs(e.verts[0].co.x - e.verts[1].co.x) > 1], cuts=8)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    o = mesh_obj(name, bm, mat or mat_backdrop(name + '_mat', color, rough), parent)
    o.location = loc
    return o


def plinth(name, r, h, mat, parent=None, loc=(0, 0, 0), square=False):
    if square:
        o = box_obj(name, r * 2, r * 2, h, mat, parent, bevel=0.003, loc=(0, 0, h / 2))
    else:
        o = cyl_obj(name, r, h, mat, parent, seg=128, loc=(0, 0, h / 2), bevel=0.003)
    o.location = Vector(loc)
    return o


# ----------------------------------------------------------------- products
def build_watch(parent_name='Watch'):
    root = empty(parent_name)
    flat = empty(parent_name + '_flat', parent=root)
    steel = mat_metal('Steel_Polished', hexc('#d9d9db'), rough=0.06)
    steel_b = mat_metal('Steel_Brushed', hexc('#cfcfd1'), rough=0.24, aniso=0.5, brushed=True)
    dial = mat_radial_brushed('Dial_Green_Sunburst', hexc('#0f4a26'), rough=0.28, aniso=0.85)
    # dial print overlay
    nt = dial.node_tree
    p = bsdf(dial)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    r_d = 0.0168
    mp.inputs['Scale'].default_value = (1 / (2 * r_d), 1 / (2 * r_d), 1)
    mp.inputs['Location'].default_value = (0.5, 0.5, 0)
    ti = image_node(nt, tex_path('dial_print.png'), extension='CLIP')
    mix = nt.nodes.new('ShaderNodeMix')
    mix.data_type = 'RGBA'
    mix.inputs[6].default_value = hexc('#0f4a26')
    nt.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], ti.inputs['Vector'])
    nt.links.new(ti.outputs['Alpha'], mix.inputs[0])
    nt.links.new(ti.outputs['Color'], mix.inputs[7])
    nt.links.new(mix.outputs[2], p.inputs['Base Color'])
    mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['To Min'].default_value = 0.55
    mr.inputs['To Max'].default_value = 0.0
    nt.links.new(ti.outputs['Alpha'], mr.inputs['Value'])
    nt.links.new(mr.outputs['Result'], p.inputs['Metallic'])

    lathe_obj('Watch_Case', [(0, -0.0058), (0.0150, -0.0058), (0.0170, -0.0049), (0.0197, -0.0030),
                             (0.0201, -0.0010), (0.0201, 0.0022), (0.0193, 0.0031), (0.0171, 0.0032),
                             (0.0170, 0.0010), (0, 0.0010)], steel_b, flat, subd=1)
    lathe_obj('Watch_Bezel', [(0.0166, 0.0031), (0.0193, 0.0031), (0.0196, 0.0038), (0.0189, 0.0049),
                              (0.0172, 0.0052), (0.0166, 0.0047), (0.0166, 0.0031)], steel, flat, subd=1)
    d = cyl_obj('Watch_Dial', r_d, 0.0004, dial, flat, seg=128, loc=(0, 0, 0.0012))
    # indices
    for i in range(12):
        a = math.pi / 2 - TAU * i / 12
        rr = 0.0128
        w = 0.0011 if i else 0.0010
        L = 0.0034 if i % 3 == 0 else 0.0026
        for k in ((-0.0008, 0.0008) if i == 0 else (0.0,)):
            ix = box_obj('Watch_Index_%02d' % i, w, L, 0.0005, steel, flat, bevel=0.0002, seg=2)
            ix.location = (rr * math.cos(a) + k * math.sin(a), rr * math.sin(a) - k * math.cos(a), 0.0016)
            ix.rotation_euler = (0, 0, a - math.pi / 2)
    # hands at 10:10:35
    def hand(name, length, width, z, angle_deg, tail=0.0025, mat=steel):
        pts = [(-width / 2, -tail), (width / 2, -tail), (width * 0.32, length), (0, length + width * 0.4),
               (-width * 0.32, length)]
        o = mesh_obj(name, bm_prism(pts, 0.00025, 'XY'), mat, flat, smooth=False)
        o.location = (0, 0, z)
        o.rotation_euler = (0, 0, -math.radians(angle_deg))
        mod_bevel(o, 0.00006, 2, angle=40)
        return o
    hand('Watch_Hand_H', 0.0085, 0.0013, 0.0018, 305)
    hand('Watch_Hand_M', 0.0130, 0.0010, 0.0021, 60)
    red = principled('Hand_Red', hexc('#c8361f'), rough=0.35)
    hand('Watch_Hand_S', 0.0148, 0.00035, 0.0024, 210, tail=0.004, mat=red)
    cyl_obj('Watch_Pinion', 0.0007, 0.0007, steel, flat, seg=32, loc=(0, 0, 0.0027))
    sapphire = mat_glass('Sapphire', ior=1.77)
    lathe_obj('Watch_Crystal', [(0, 0.0054), (0.010, 0.0053), (0.0158, 0.0050), (0.0168, 0.0048),
                                (0.0168, 0.0043), (0.0158, 0.0043), (0.010, 0.0046), (0, 0.0047)], sapphire, flat, seg=128)
    cr = cyl_obj('Watch_Crown', 0.0027, 0.0032, steel, flat, seg=48, loc=(0.0214, 0, -0.0004), bevel=0.0004, axis='X')
    cyl_obj('Watch_CrownStem', 0.0012, 0.0016, steel, flat, seg=24, loc=(0.0200, 0, -0.0004), axis='X')
    for sx in (-1, 1):
        for sy in (-1, 1):
            lug = box_obj('Watch_Lug', 0.0047, 0.0082, 0.0058, steel_b, flat, bevel=0.0019, seg=6)
            lug.location = (sx * 0.0127, sy * 0.0197, -0.0011)
            lug.rotation_euler = (math.radians(-14 * sy), 0, 0)
    # leather strap loop
    leather = principled('Leather_Black', hexc('#141211'), rough=0.52, coat=0.08, coat_rough=0.35)
    add_bump(leather, 0.25, 900, 2, kind='voronoi')
    ry, rz = 0.031, 0.033
    th0 = math.asin(0.0245 / ry)
    zc = -0.0018 - rz * math.cos(th0)
    pts = []
    N = 160
    for i in range(N + 1):
        th = th0 + (TAU - 2 * th0) * i / N
        pts.append((0, ry * math.sin(th), zc + rz * math.cos(th)))
    strap = mesh_obj('Watch_Strap', sweep_rect(pts, 0.0198, 0.0034), leather, flat)
    mod_subsurf(strap, 1)
    keeper = mesh_obj('Watch_Keeper', sweep_rect([(0, ry * math.sin(math.pi + a), zc + rz * math.cos(math.pi + a))
                                                  for a in [x * 0.02 for x in range(-6, 7)]], 0.0215, 0.0062), leather, flat)
    flat.rotation_euler = (math.radians(90), 0, 0)
    flat.location = (0, 0, ry + 0.0018)
    return root


def build_perfume(name='Perfume'):
    root = empty(name)
    W, D, H = 0.060, 0.034, 0.074
    glass = mat_glass('Perfume_Glass', ior=1.52)
    add_noise_rough(glass, 0.0, 0.015, scale=40)
    bm = bm_prism(rounded_rect(W, D, 0.004, 8), H, 'XY')
    inner = bm_prism(rounded_rect(W - 0.013, D - 0.013, 0.002, 6), H - 0.024, 'XY', z0=0.017)
    o = mesh_obj('Perfume_Bottle', bm, glass, root)
    mod_bevel(o, 0.0035, 6, angle=60, harden=False)
    bmesh.ops.reverse_faces(inner, faces=inner.faces[:])
    cav = mesh_obj('Perfume_Cavity', inner, glass, root)
    mod_bevel(cav, 0.0012, 3, angle=60)
    liquid = mat_glass('Perfume_Liquid', color=hexc('#f1dfa6'), ior=1.36)
    lq = mesh_obj('Perfume_Liquid', bm_prism(rounded_rect(W - 0.0134, D - 0.0134, 0.0019, 6), (H - 0.024) * 0.78, 'XY', z0=0.0172), liquid, root)
    mod_bevel(lq, 0.0010, 3, angle=60)
    gold = mat_metal('Gold_Polished', hexc('#e3c08a'), rough=0.10)
    cyl_obj('Perfume_Collar', 0.0085, 0.008, gold, root, seg=96, loc=(0, 0, H + 0.004), bevel=0.0006)
    cap_m = principled('Cap_Black_SoftTouch', hexc('#101010'), rough=0.42, coat=0.2, coat_rough=0.25)
    cap = rounded_slab('Perfume_Cap', 0.030, 0.030, 0.026, 0.004, 0.0025, cap_m, root, plane='XY')
    cap.location = (0, 0, H + 0.0075)
    lbl = mat_label('Perfume_Label_Mat', 'perfume_label.png', rough=0.6)
    lab = plane_obj('Perfume_Label', 0.036, 0.0225, lbl, root)
    lab.location = (0, -D / 2 - 0.00025, H * 0.47)
    return root


def build_earbuds_case(name='Earbuds'):
    root = empty(name)
    W, Dp, Hh = 0.0606, 0.0217, 0.0452
    white = principled('Plastic_Gloss_White', hexc('#f2f2f0'), rough=0.16, coat=0.5, coat_rough=0.04, sss=0.05, sss_scale=0.002)
    add_noise_rough(white, 0.16, 0.05, scale=25)
    split = 0.0322
    gap = 0.0003

    def part(nm, z0, z1):
        bm = bm_prism(rounded_rect(W, Hh, 0.0135, 16), Dp, 'XZ')
        for v in bm.verts:
            v.co.z += Hh / 2
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
        bmesh.ops.bevel(bm, geom=[e for e in bm.edges if abs(e.verts[0].co.y - e.verts[1].co.y) < 1e-6],
                        offset=0.0078, segments=10, profile=0.5, affect='EDGES', clamp_overlap=True)
        r1 = bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=(0, 0, z0),
                                    plane_no=(0, 0, 1), clear_inner=True)
        r2 = bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=(0, 0, z1),
                                    plane_no=(0, 0, 1), clear_outer=True)
        bmesh.ops.holes_fill(bm, edges=bm.edges[:], sides=0)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        o = mesh_obj(nm, bm, white, root)
        mod_bevel(o, 0.0003, 2, angle=60)
        return o
    part('Earbuds_Base', -1, split - gap / 2)
    part('Earbuds_Lid', split + gap / 2, 1)
    led = mat_emission('LED_White', (1, 1, 1, 1), 6.0)
    cyl_obj('Earbuds_LED', 0.0006, 0.0003, led, root, seg=24, loc=(0, -Dp / 2 - 0.00002, 0.020), axis='Y')
    steel = mat_metal('Steel_Polished', hexc('#d9d9db'), 0.06)
    cyl_obj('Earbuds_Hinge', 0.0016, 0.012, steel, root, seg=32, loc=(0, Dp / 2 - 0.0005, split), axis='X')
    return root


def build_sunglasses(name='Sunglasses'):
    root = empty(name)
    frame = mat_tortoise('Acetate_Tortoise')
    lens_m = mat_glass('Lens_Tint', color=hexc('#1c2a22'), rough=0.0, ior=1.55, film=380.0)
    _set(bsdf(lens_m), 'Thin Film IOR', 1.9)
    a, b = 0.0262, 0.0215
    lens2d = squircle(a, b, 3.2, 120, skew=0.06)
    outer2d = squircle(a + 0.0042, b + 0.0040, 3.0, 120, skew=0.06)

    def curve_front(v, cx):
        x = v.co.x
        v.co.y += 1.8 * (x * x) + 0.6 * ((v.co.x - cx) ** 2 + v.co.z ** 2)

    for side in (-1, 1):
        cx = side * 0.0345
        bm = bmesh.new()
        inner = [bm.verts.new((cx + x, -0.002, z)) for x, z in lens2d]
        outer = [bm.verts.new((cx + x, -0.002, z)) for x, z in outer2d]
        n = len(lens2d)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((inner[i], inner[j], outer[j], outer[i]))
        ext = bmesh.ops.extrude_face_region(bm, geom=bm.faces[:])
        for v in [e for e in ext['geom'] if isinstance(e, bmesh.types.BMVert)]:
            v.co.y += 0.0048
        for v in bm.verts:
            curve_front(v, cx)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        rim = mesh_obj('Sun_Rim_%s' % ('L' if side < 0 else 'R'), bm, frame, root)
        mod_bevel(rim, 0.0009, 4, angle=40)
        bm = bmesh.new()
        lv = [bm.verts.new((cx + x * 1.03, 0.0002, z * 1.03)) for x, z in lens2d]
        bm.faces.new(lv)
        bmesh.ops.extrude_face_region(bm, geom=bm.faces[:])
        for v in bm.verts[n:]:
            v.co.y += 0.0016
        for v in bm.verts:
            curve_front(v, cx)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        mesh_obj('Sun_Lens_%s' % ('L' if side < 0 else 'R'), bm, lens_m, root)
        # temple
        tx = side * (0.0345 + a + 0.0030)
        hinge_y = 1.8 * tx * tx + 0.006
        L = 0.138
        tpts = []
        for i in range(41):
            t = i / 40
            yy = hinge_y + L * t
            zz = 0.0115 - (0.018 * max(0, (t - 0.78) / 0.22) ** 2)
            tpts.append((0, yy, zz))
        tb = sweep_rect([(0, p[1], p[2]) for p in tpts], 0.0032, 0.0050)
        tm = mesh_obj('Sun_Temple_%s' % ('L' if side < 0 else 'R'), tb, frame, root)
        tm.location.x = tx + side * 0.0005
        tm.rotation_euler = (0, 0, math.radians(-4 * side))
        mod_subsurf(tm, 1)
        steel = mat_metal('Steel_Polished', hexc('#d9d9db'), 0.06)
        box_obj('Sun_Hinge', 0.0035, 0.006, 0.0042, steel, root, bevel=0.0006, loc=(tx, hinge_y + 0.002, 0.0115))
    # bridge
    bpts = []
    for i in range(21):
        t = i / 20
        x = -0.0095 + 0.019 * t
        z = 0.0115 + 0.0035 * math.sin(math.pi * t)
        bpts.append((x, 1.8 * x * x + 0.0005, z))
    bridge = sweep_rect(bpts, 0.0042, 0.0040, side=(0, 1, 0))
    o = mesh_obj('Sun_Bridge', bridge, frame, root)
    mod_subsurf(o, 1)
    root.rotation_euler = (math.radians(-8.3), 0, 0)
    root.location.z = 0.0298
    return root


def build_candle(name='Candle'):
    root = empty(name)
    amber = mat_glass('Amber_Glass', color=hexc('#a85a17'), rough=0.02, ior=1.5)
    add_noise_rough(amber, 0.02, 0.02, scale=15)
    lathe_obj('Candle_Jar', [(0, 0), (0.0395, 0), (0.0418, 0.0015), (0.0420, 0.004), (0.0420, 0.0880),
                             (0.0412, 0.0898), (0.0396, 0.0898), (0.0390, 0.0885), (0.0390, 0.0070),
                             (0.0370, 0.0060), (0, 0.0060)], amber, root, seg=128)
    wax = principled('Soy_Wax', hexc('#efe5d3'), rough=0.45, sss=1.0, sss_scale=0.006,
                     sss_radius=(1.0, 0.75, 0.5))
    lathe_obj('Candle_Wax', [(0, 0.0062), (0.0386, 0.0062), (0.0386, 0.0700), (0.0360, 0.0703),
                             (0.0200, 0.0697), (0, 0.0694)], wax, root, seg=128)
    wick = principled('Wood_Wick', hexc('#2b211a'), rough=0.8)
    w = box_obj('Candle_Wick', 0.010, 0.0012, 0.010, wick, root, bevel=0.0002, loc=(0, 0, 0.0745))
    w.rotation_euler = (0, math.radians(2), math.radians(25))
    lbl = mat_label('Candle_Label_Mat', 'candle_label.png', rough=0.75)
    cylinder_band('Candle_Label', 0.04215, 0.026, 0.060, -math.pi / 2 - 1.15, -math.pi / 2 + 1.15, lbl, root)
    return root


def build_serum(name='Serum'):
    root = empty(name)
    amber = mat_glass('Amber_Glass', color=hexc('#a85a17'), rough=0.02, ior=1.5)
    R = 0.0165
    lathe_obj('Serum_Bottle', [(0, 0), (R - 0.0015, 0), (R, 0.0018), (R, 0.0560), (R - 0.001, 0.0605),
                               (0.0120, 0.0645), (0.0088, 0.0665), (0.0086, 0.0720), (0.0068, 0.0720),
                               (0.0068, 0.0660), (0.0100, 0.0635), (R - 0.0028, 0.0590), (R - 0.0018, 0.0555),
                               (R - 0.0018, 0.0040), (0, 0.0040)], amber, root, seg=128)
    liquid = mat_glass('Serum_Liquid', color=hexc('#f3b25a'), ior=1.38)
    lathe_obj('Serum_Liquid', [(0, 0.0042), (R - 0.0019, 0.0042), (R - 0.0019, 0.0430), (0, 0.0430)], liquid, root, seg=96)
    white = principled('Plastic_Matte_White', hexc('#f4f3ef'), rough=0.38, sss=0.1, sss_scale=0.002)
    lathe_obj('Serum_Collar', [(0.0085, 0.0660), (0.0102, 0.0660), (0.0104, 0.0670), (0.0104, 0.0815),
                               (0.0098, 0.0822), (0.0060, 0.0822), (0.0060, 0.0660)], white, root, seg=96)
    rubber = principled('Rubber_White', hexc('#ecebe6'), rough=0.6, sss=0.3, sss_scale=0.003)
    lathe_obj('Serum_Bulb', [(0, 0.0820), (0.0074, 0.0820), (0.0080, 0.0860), (0.0078, 0.0950),
                             (0.0068, 0.1020), (0.0045, 0.1065), (0, 0.1078)], rubber, root, seg=96, subd=1)
    clear = mat_glass('Clear_Glass', ior=1.5)
    lathe_obj('Serum_Pipette', [(0, 0.012), (0.0020, 0.012), (0.0028, 0.016), (0.0028, 0.080),
                                (0.0019, 0.080), (0.0019, 0.017), (0, 0.016)], clear, root, seg=48)
    lbl = mat_label('Serum_Label_Mat', 'serum_label.png', rough=0.55)
    span = 2.667 * 0.036 / R
    a0 = -math.pi / 2 - 0.25 * span
    cylinder_band('Serum_Label', R + 0.00012, 0.010, 0.046, a0, a0 + span, lbl, root, seg=160)
    return root


def build_lipstick(name='Lipstick'):
    root = empty(name)
    gold = mat_metal('Gold_Polished', hexc('#e3c08a'), rough=0.10)
    gold_b = mat_metal('Gold_Brushed', hexc('#d8b47e'), rough=0.26, brushed=True)
    lathe_obj('Lip_Base', [(0, 0), (0.0092, 0), (0.0096, 0.0006), (0.0096, 0.0300), (0.0092, 0.0306), (0, 0.0306)], gold_b, root, seg=96)
    lathe_obj('Lip_Sleeve', [(0, 0.0300), (0.0079, 0.0300), (0.0079, 0.0440), (0.0076, 0.0444), (0, 0.0444)], gold, root, seg=96)
    red = principled('Lipstick_Red', hexc('#7d0d1c'), rough=0.3, sss=0.25, sss_scale=0.002, sss_radius=(1, 0.3, 0.2),
                     coat=0.3, coat_rough=0.2)
    bm = bm_lathe([(0, 0.040), (0.0064, 0.040), (0.0064, 0.0700), (0, 0.0700)], 96)
    bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=(0, 0, 0.0575),
                           plane_no=Vector((0.62, 0, 1)).normalized(), clear_outer=True)
    bmesh.ops.holes_fill(bm, edges=bm.edges[:], sides=0)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bullet = mesh_obj('Lip_Bullet', bm, red, root)
    mod_bevel(bullet, 0.0011, 5, angle=25)
    cap = lathe_obj('Lip_Cap', [(0.0094, 0.0), (0.0098, 0.0), (0.0098, 0.0395), (0.0094, 0.0400), (0, 0.0400),
                                (0, 0.0392), (0.0090, 0.0392), (0.0090, 0.0006)], gold_b, root, seg=96)
    cap.rotation_euler = (math.radians(90), 0, math.radians(-30))
    cap.location = (0.026, 0.012, 0.0098)
    return root


def build_shipping_box(name='ShipBox'):
    root = empty(name)
    W, D, H = 0.34, 0.24, 0.16
    card = mat_cardboard('Cardboard')
    b = box_obj('Box_Body', W, D, H - 0.003, card, root, bevel=0.0025, seg=3, loc=(0, 0, (H - 0.003) / 2))
    for s in (-1, 1):
        f = box_obj('Box_Flap', W - 0.002, D / 2 - 0.001, 0.003, card, root, bevel=0.0012, seg=2,
                    loc=(0, s * (D / 4 + 0.0003), H - 0.0015))
    tape = principled('Tape_Green', (1, 1, 1, 1), rough=0.22, coat=0.6, coat_rough=0.08)
    nt = tape.node_tree
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    t = image_node(nt, tex_path('tape.png'))
    nt.links.new(tc.outputs['UV'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], t.inputs['Vector'])
    nt.links.new(t.outputs['Color'], bsdf(tape).inputs['Base Color'])
    tw = 0.048
    # tape path: front side up, across top, down back side
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new('UVMap')
    path = [(-W / 2 - 0.0004, 0, H - 0.075), (-W / 2 - 0.0004, 0, H + 0.0004), (W / 2 + 0.0004, 0, H + 0.0004),
            (W / 2 + 0.0004, 0, H - 0.075)]
    acc = [0.0]
    for p0, p1 in zip(path[:-1], path[1:]):
        acc.append(acc[-1] + (Vector(p1) - Vector(p0)).length)
    rows = [(bm.verts.new((p[0], -tw / 2, p[2])), bm.verts.new((p[0], tw / 2, p[2]))) for p in path]
    texlen = tw * 2048 / 192
    for i in range(len(path) - 1):
        f = bm.faces.new((rows[i][0], rows[i + 1][0], rows[i + 1][1], rows[i][1]))
        for lp, uvv in zip(f.loops, ((acc[i] / texlen, 0), (acc[i + 1] / texlen, 0), (acc[i + 1] / texlen, 1), (acc[i] / texlen, 1))):
            lp[uv].uv = uvv
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    for f in bm.faces:
        c = f.calc_center_median()
        if f.normal.dot(Vector((c.x, 0, c.z - H / 2))) < 0:
            f.normal_flip()
    mesh_obj('Box_Tape', bm, tape, root, smooth=False)
    lbl = mat_label('ShipLabel_Mat', 'ship_label.png', rough=0.5)
    sl = plane_obj('Box_Label', 0.105, 0.070, lbl, root, plane='XY')
    sl.location = (0.095, -0.055, H + 0.0006)
    sl.rotation_euler = (0, 0, math.radians(-3))
    return root


def build_paper_bag(name='PaperBag'):
    root = empty(name)
    W, D, H = 0.26, 0.12, 0.32
    paper = mat_paper('Bag_Paper_Green', GREEN, rough=0.58, bump=0.16)
    nt = paper.node_tree
    pb = bsdf(paper)
    t = image_node(nt, tex_path('bag_logo.png'), extension='CLIP')
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mix = nt.nodes.new('ShaderNodeMix')
    mix.data_type = 'RGBA'
    mix.inputs[6].default_value = GREEN
    mix.inputs[7].default_value = (0.86, 0.87, 0.85, 1)
    nt.links.new(tc.outputs['UV'], t.inputs['Vector'])
    nt.links.new(t.outputs['Alpha'], mix.inputs[0])
    nt.links.new(mix.outputs[2], pb.inputs['Base Color'])
    bm = bmesh.new()
    nx, ny, nz = 12, 6, 16
    # open-top box with side gusset creases
    def P(u, v, w):
        x = -W / 2 + W * u
        y = -D / 2 + D * v
        z = H * w
        return x, y, z
    verts = {}
    def V(x, y, z):
        k = (round(x, 6), round(y, 6), round(z, 6))
        if k not in verts:
            verts[k] = bm.verts.new(k)
        return verts[k]
    def grid(corner, du, dv, nu, nv):
        for i in range(nu):
            for j in range(nv):
                q = []
                for a, bb in ((i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)):
                    p = Vector(corner) + Vector(du) * (a / nu) + Vector(dv) * (bb / nv)
                    q.append(V(p.x, p.y, p.z))
                try:
                    bm.faces.new(q)
                except ValueError:
                    pass
    grid((-W / 2, -D / 2, 0), (W, 0, 0), (0, 0, H), nx, nz)            # front
    grid((W / 2, D / 2, 0), (-W, 0, 0), (0, 0, H), nx, nz)             # back
    grid((W / 2, -D / 2, 0), (0, D, 0), (0, 0, H), ny, nz)             # right
    grid((-W / 2, D / 2, 0), (0, -D, 0), (0, 0, H), ny, nz)            # left
    grid((-W / 2, D / 2, 0), (W, 0, 0), (0, -D, 0), nx, ny)            # bottom
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-6)
    for v in bm.verts:
        if abs(abs(v.co.x) - W / 2) < 1e-6 and 0.02 < v.co.z < H - 0.001:
            t = 1 - abs(v.co.y) / (D / 2)
            v.co.x -= math.copysign(0.010 * t * min(1, v.co.z / 0.05), v.co.x)
        # gentle bulge on faces
        if abs(abs(v.co.y) - D / 2) < 1e-6:
            v.co.y += math.copysign(0.004 * math.sin(math.pi * (v.co.x + W / 2) / W) * math.sin(math.pi * min(v.co.z / H, 1)), v.co.y)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    uvl = bm.loops.layers.uv.new('UVMap')
    LS, LZ = 0.150, H * 0.54
    for f in bm.faces:
        c = f.calc_center_median()
        front = c.y < -D / 2 + 0.003 and abs(c.x) < W / 2 - 0.004 and c.z > 0.001
        for lp in f.loops:
            co = lp.vert.co
            lp[uvl].uv = ((co.x / LS + 0.5, (co.z - LZ) / LS + 0.5) if front else (5.0, 5.0))
    o = mesh_obj('Bag_Body', bm, paper, root)
    mod_solidify(o, 0.0007, offset=-1)
    d = o.modifiers.new('Wrinkle', 'DISPLACE')
    tx = bpy.data.textures.new('BagWrinkle', 'CLOUDS')
    tx.noise_scale = 0.045
    tx.noise_depth = 3
    d.texture = tx
    d.strength = 0.0032
    d.texture_coords = 'OBJECT'
    # handles (twisted paper rope)
    rope = mat_paper('Bag_Rope', hexc('#e9e3d6'), rough=0.7, bump=0.4)
    for s in (-1, 1):
        pts = []
        for i in range(41):
            t = i / 40
            x = -0.055 + 0.11 * t
            z = H - 0.025 + 0.115 * math.sin(math.pi * t) ** 0.8
            pts.append((x, s * (D / 2 + 0.002), z))
        cu = bpy.data.curves.new('BagHandle', 'CURVE')
        cu.dimensions = '3D'
        sp = cu.splines.new('POLY')
        sp.points.add(len(pts) - 1)
        for p, c in zip(sp.points, pts):
            p.co = (c[0], c[1], c[2], 1)
        cu.bevel_depth = 0.0028
        cu.bevel_resolution = 4
        ho = bpy.data.objects.new('Bag_Handle', cu)
        link(ho)
        ho.parent = root
        cu.materials.append(rope)
    return root


# ----------------------------------------------------------------- phone
PHONE = dict(W=0.0716, H=0.1476, D=0.0083, R=0.0118, DW=0.0662)
PHONE['DH'] = PHONE['DW'] * 2556 / 1179


def build_phone(name='Phone', frame_color='#8c877f', back_color='#2b2c2e'):
    root = empty(name)
    W, H, D, R = PHONE['W'], PHONE['H'], PHONE['D'], PHONE['R']
    ti = mat_metal('Titanium_' + name, hexc(frame_color), rough=0.27, aniso=0.35, brushed=True)
    body = rounded_slab(name + '_Frame', W, H, D, R, 0.0019, ti, root, seg=16, edge_seg=7)
    glass_black = principled('Phone_FrontGlass', (0.004, 0.004, 0.0045, 1), rough=0.03, spec=0.7, coat=1.0, coat_rough=0.01)
    add_noise_rough(glass_black, 0.03, 0.025, scale=9, detail=10)
    fg = rounded_slab(name + '_Glass', W - 0.0011, H - 0.0011, 0.0010, R - 0.0005, 0.00045, glass_black, root, seg=16, edge_seg=4)
    fg.location.y = -D / 2 - 0.00005
    back = principled('Phone_BackGlass_' + name, hexc(back_color), rough=0.36, spec=0.5)
    add_noise_rough(back, 0.36, 0.05, scale=40, detail=6)
    bg = rounded_slab(name + '_Back', W - 0.0011, H - 0.0011, 0.0008, R - 0.0005, 0.0004, back, root, seg=16, edge_seg=3)
    bg.location.y = D / 2 + 0.00005
    # display (emissive), dynamic island
    DW, DH = PHONE['DW'], PHONE['DH']
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new('UVMap')
    pts = rounded_rect(DW, DH, 0.0098, 14)
    vs = [bm.verts.new((x, 0, z)) for x, z in pts]
    f = bm.faces.new(vs)
    for lp in f.loops:
        lp[uv].uv = ((lp.vert.co.x + DW / 2) / DW, (lp.vert.co.z + DH / 2) / DH)
    f.normal_update()
    if f.normal.y > 0:
        f.normal_flip()
    disp = mesh_obj(name + '_Display', bm, None, root, smooth=False)
    disp.location.y = -D / 2 - 0.00057
    di = principled('Phone_Island', (0.002, 0.002, 0.002, 1), rough=0.05, spec=0.6)
    bm = bmesh.new()
    pv = [bm.verts.new((x, 0, z)) for x, z in rounded_rect(0.0124, 0.0036, 0.0018, 8)]
    f = bm.faces.new(pv)
    f.normal_update()
    if f.normal.y > 0:
        f.normal_flip()
    isl = mesh_obj(name + '_Island', bm, di, root, smooth=False)
    isl.location = (0, -D / 2 - 0.00060, DH / 2 - 0.0011 - 0.0018)
    # side buttons
    for nm, side, zc, ln in (('Power', 1, 0.022, 0.0175), ('Action', -1, 0.043, 0.0055),
                             ('VolUp', -1, 0.028, 0.0095), ('VolDn', -1, 0.016, 0.0095)):
        btn = box_obj(name + '_Btn' + nm, 0.0012, 0.0026, ln, ti, root, bevel=0.0005, seg=3,
                      loc=(side * (W / 2 - 0.0002), 0, zc))
    # antenna lines
    band = principled('Antenna_Band', hexc('#77736d'), rough=0.45)
    for sx, sz in ((1, 0.064), (-1, 0.064), (1, -0.064), (-1, -0.064)):
        box_obj(name + '_Antenna', 0.0003, D * 0.5, 0.0009, band, root, loc=(sx * (W / 2 + 0.00004), 0, sz))
    # bottom port + speaker grilles
    blk = principled('Port_Black', (0.003, 0.003, 0.003, 1), rough=0.6)
    port = rounded_slab(name + '_Port', 0.0089, 0.0031, 0.0016, 0.0015, 0.0002, blk, root, plane='XY')
    port.location = (0, 0, -H / 2 - 0.00008)
    for sx in (-1, 1):
        for k in range(6):
            cyl_obj(name + '_Grille', 0.0006, 0.0012, blk, root, seg=16,
                    loc=(sx * (0.0115 + k * 0.0024), 0, -H / 2 + 0.0004))
    # rear camera plateau
    cam_root = empty(name + '_Cam', parent=root)
    cam_root.location = (W / 2 - 0.0035 - 0.0183, D / 2 + 0.0001, H / 2 - 0.0035 - 0.0188)
    plat_m = principled('Plateau_Glass_' + name, hexc(back_color), rough=0.05, spec=0.6, coat=1.0, coat_rough=0.02)
    plat = rounded_slab(name + '_Plateau', 0.0366, 0.0376, 0.0013, 0.0082, 0.0005, plat_m, cam_root, plane='XZ')
    plat.location.y = 0.0010
    ring_m = mat_metal('Lens_Ring_' + name, hexc(frame_color), rough=0.12)
    lens_m = principled('Lens_Element', (0.002, 0.002, 0.004, 1), rough=0.02, spec=1.0, film=320.0, film_ior=1.7)
    nt = lens_m.node_tree
    tc = nt.nodes.new('ShaderNodeTexCoord')
    grad = nt.nodes.new('ShaderNodeTexGradient')
    grad.gradient_type = 'SPHERICAL'
    mp = nt.nodes.new('ShaderNodeMapping')
    mp.inputs['Scale'].default_value = (190, 190, 190)
    ramp = nt.nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.interpolation = 'CONSTANT'
    ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1)
    ramp.color_ramp.elements[1].position = 0.55
    ramp.color_ramp.elements[1].color = (0.02, 0.02, 0.025, 1)
    e = ramp.color_ramp.elements.new(0.8)
    e.color = (0.006, 0.006, 0.01, 1)
    nt.links.new(tc.outputs['Object'], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], grad.inputs['Vector'])
    nt.links.new(grad.outputs['Fac'], ramp.inputs['Fac'])
    nt.links.new(ramp.outputs['Color'], bsdf(lens_m).inputs['Base Color'])
    for lx, lz in ((0.0086, 0.0091), (0.0086, -0.0091), (-0.0088, 0.0)):
        L = empty(name + '_Lens', parent=cam_root)
        L.location = (lx, 0.0018, lz)
        L.rotation_euler = (math.radians(-90), 0, 0)
        lathe_obj(name + '_LensRing', [(0.0051, 0.0), (0.0069, 0.0), (0.0069, 0.0011), (0.0065, 0.0018),
                                       (0.0055, 0.0018), (0.0052, 0.0013), (0.0051, 0.0)], ring_m, L, seg=96, subd=1)
        cyl_obj(name + '_LensGlass', 0.0052, 0.0006, lens_m, L, seg=96, loc=(0, 0, 0.0010))
    flash = principled('Flash', hexc('#efe9d9'), rough=0.25, sss=0.4)
    cyl_obj(name + '_Flash', 0.0024, 0.0004, flash, cam_root, seg=48, loc=(-0.0090, 0.0019, 0.0112), axis='Y')
    cyl_obj(name + '_Lidar', 0.0020, 0.0004, lens_m, cam_root, seg=48, loc=(-0.0090, 0.0019, -0.0112), axis='Y')
    return root, disp


# ----------------------------------------------------------------- screen shader
def screen_material(name, layers, chrome=None, base=(1, 1, 1, 1)):
    """layers: list of dicts {key, file, height_px}. Each layer gets nodes named
    '<key>_map' (Mapping: Location x = slide offset, y set by scroll) and
    '<key>_op' (Value: opacity). Emission strength node: 'screen_power'."""
    mat = bpy.data.materials.new(name)
    nt, out = _nt(mat)
    p = nt.nodes.new('ShaderNodeBsdfPrincipled')
    _set(p, 'Base Color', (0.0, 0.0, 0.0, 1))
    _set(p, 'Roughness', 0.04)
    _set(p, 'Specular IOR Level', 0.32)
    _set(p, 'Coat Weight', 0.25)
    _set(p, 'Coat Roughness', 0.02)
    tc = nt.nodes.new('ShaderNodeTexCoord')
    col = nt.nodes.new('ShaderNodeRGB')
    col.outputs[0].default_value = base
    cur = col.outputs[0]
    y = 0
    for L in layers:
        key = L['key']
        Hpx = L.get('height_px', 2556)
        mp = nt.nodes.new('ShaderNodeMapping')
        mp.name = key + '_map'
        mp.vector_type = 'POINT'
        mp.inputs['Scale'].default_value = (1, 2556 / Hpx, 1)
        mp.inputs['Location'].default_value = (0, 1 - 2556 / Hpx, 0)
        mp['height_px'] = Hpx
        tx = image_node(nt, screen_path(L['file']), extension='CLIP', interp='Cubic')
        tx.name = key + '_img'
        op = nt.nodes.new('ShaderNodeValue')
        op.name = key + '_op'
        op.outputs[0].default_value = 0.0
        mul = nt.nodes.new('ShaderNodeMath')
        mul.operation = 'MULTIPLY'
        mix = nt.nodes.new('ShaderNodeMix')
        mix.data_type = 'RGBA'
        nt.links.new(tc.outputs['UV'], mp.inputs['Vector'])
        nt.links.new(mp.outputs[0], tx.inputs['Vector'])
        nt.links.new(tx.outputs['Alpha'], mul.inputs[0])
        nt.links.new(op.outputs[0], mul.inputs[1])
        nt.links.new(mul.outputs[0], mix.inputs[0])
        nt.links.new(cur, mix.inputs[6])
        nt.links.new(tx.outputs['Color'], mix.inputs[7])
        cur = mix.outputs[2]
        if L.get('sticky_px'):
            # sticky header: same image sampled without scroll, masked to top rows
            sp = L['sticky_px']
            mp2 = nt.nodes.new('ShaderNodeMapping')
            mp2.inputs['Scale'].default_value = (1, 2556 / Hpx, 1)
            mp2.inputs['Location'].default_value = (0, 1 - 2556 / Hpx, 0)
            mp2.name = key + '_stickymap'
            tx2 = image_node(nt, screen_path(L['file']), extension='CLIP', interp='Cubic')
            sep = nt.nodes.new('ShaderNodeSeparateXYZ')
            gt = nt.nodes.new('ShaderNodeMath')
            gt.operation = 'GREATER_THAN'
            gt.inputs[1].default_value = 1 - sp / 2556
            m2 = nt.nodes.new('ShaderNodeMath')
            m2.operation = 'MULTIPLY'
            m3 = nt.nodes.new('ShaderNodeMath')
            m3.operation = 'MULTIPLY'
            mixs = nt.nodes.new('ShaderNodeMix')
            mixs.data_type = 'RGBA'
            nt.links.new(tc.outputs['UV'], mp2.inputs['Vector'])
            nt.links.new(mp2.outputs[0], tx2.inputs['Vector'])
            nt.links.new(tc.outputs['UV'], sep.inputs[0])
            nt.links.new(sep.outputs['Y'], gt.inputs[0])
            nt.links.new(gt.outputs[0], m2.inputs[0])
            nt.links.new(tx2.outputs['Alpha'], m2.inputs[1])
            nt.links.new(m2.outputs[0], m3.inputs[0])
            nt.links.new(op.outputs[0], m3.inputs[1])
            nt.links.new(m3.outputs[0], mixs.inputs[0])
            nt.links.new(cur, mixs.inputs[6])
            nt.links.new(tx2.outputs['Color'], mixs.inputs[7])
            cur = mixs.outputs[2]
    if chrome:
        txc = image_node(nt, screen_path(chrome), extension='CLIP')
        opc = nt.nodes.new('ShaderNodeValue')
        opc.name = 'chrome_op'
        opc.outputs[0].default_value = 1.0
        mulc = nt.nodes.new('ShaderNodeMath')
        mulc.operation = 'MULTIPLY'
        mixc = nt.nodes.new('ShaderNodeMix')
        mixc.data_type = 'RGBA'
        nt.links.new(tc.outputs['UV'], txc.inputs['Vector'])
        nt.links.new(txc.outputs['Alpha'], mulc.inputs[0])
        nt.links.new(opc.outputs[0], mulc.inputs[1])
        nt.links.new(mulc.outputs[0], mixc.inputs[0])
        nt.links.new(cur, mixc.inputs[6])
        nt.links.new(txc.outputs['Color'], mixc.inputs[7])
        cur = mixc.outputs[2]
    pw = nt.nodes.new('ShaderNodeValue')
    pw.name = 'screen_power'
    pw.outputs[0].default_value = 1.0
    nt.links.new(cur, p.inputs['Emission Color'])
    nt.links.new(pw.outputs[0], p.inputs['Emission Strength'])
    nt.links.new(p.outputs[0], out.inputs[0])
    return mat


def key_value(mat, node_name, frame, value, interp='BEZIER', socket=0):
    n = mat.node_tree.nodes[node_name]
    s = n.outputs[socket] if n.type == 'VALUE' else n.inputs[socket]
    s.default_value = value
    s.keyframe_insert('default_value', frame=frame)
    _interp_last(mat.node_tree, interp)


def key_scroll(mat, key, frame, scroll_px, slide_x=0.0, interp='BEZIER'):
    mp = mat.node_tree.nodes[key + '_map']
    Hpx = mp['height_px']
    loc = mp.inputs['Location']
    loc.default_value = (slide_x, 1 - (scroll_px + 2556) / Hpx, 0)
    loc.keyframe_insert('default_value', frame=frame)
    _interp_last(mat.node_tree, interp)


def _interp_last(idblock, interp):
    ad = idblock.animation_data
    if not ad or not ad.action:
        return
    for fc in _fcurves(ad.action):
        for kp in fc.keyframe_points:
            if kp.interpolation != interp and interp != 'BEZIER':
                kp.interpolation = interp


def _fcurves(action):
    if hasattr(action, 'fcurves') and len(getattr(action, 'fcurves', [])) >= 0:
        try:
            return list(action.fcurves)
        except Exception:
            pass
    out = []
    for layer in getattr(action, 'layers', []):
        for strip in layer.strips:
            for cb in getattr(strip, 'channelbags', []):
                out.extend(cb.fcurves)
    return out


def all_fcurves(idblock):
    ad = getattr(idblock, 'animation_data', None)
    if not ad or not ad.action:
        return []
    return _fcurves(ad.action)


# ----------------------------------------------------------------- render setup
def setup_render(scene, res=(1920, 1080), samples=128, fps=24, gpu=True, look='Khronos PBR Neutral'):
    scene.render.engine = 'CYCLES'
    cy = scene.cycles
    cy.samples = samples
    cy.use_adaptive_sampling = True
    cy.adaptive_threshold = 0.03
    cy.adaptive_min_samples = 12
    cy.use_denoising = True
    try:
        cy.denoiser = 'OPENIMAGEDENOISE'
        cy.denoising_input_passes = 'RGB_ALBEDO_NORMAL'
        cy.denoising_prefilter = 'ACCURATE'
        cy.denoising_quality = 'HIGH'
        cy.denoising_use_gpu = True
    except Exception:
        pass
    try:
        cy.auto_scrambling_distance = True
    except Exception:
        pass
    cy.max_bounces = 10
    cy.diffuse_bounces = 2
    cy.glossy_bounces = 4
    cy.transmission_bounces = 10
    cy.transparent_max_bounces = 8
    cy.volume_bounces = 0
    cy.caustics_reflective = False
    cy.caustics_refractive = False
    cy.blur_glossy = 1.0
    cy.sample_clamp_indirect = 6.0
    cy.sample_clamp_direct = 0.0
    cy.film_exposure = 1.0
    cy.pixel_filter_type = 'BLACKMAN_HARRIS'
    cy.filter_width = 1.5
    scene.render.use_persistent_data = True
    scene.render.resolution_x, scene.render.resolution_y = res
    scene.render.resolution_percentage = 100
    scene.render.fps = fps
    scene.render.use_motion_blur = True
    scene.render.motion_blur_shutter = 0.45
    vs = scene.view_settings
    try:
        vs.view_transform = look
    except TypeError:
        vs.view_transform = 'AgX'
    try:
        vs.look = 'None'
    except TypeError:
        pass
    vs.exposure = 0.0
    vs.gamma = 1.0
    scene.display_settings.display_device = 'sRGB'
    picked = enable_gpu(scene) if gpu else None
    print('RENDER_DEVICE', picked or 'CPU', flush=True)


def enable_gpu(scene):
    prefs = bpy.context.preferences
    cp = prefs.addons['cycles'].preferences
    picked = None
    for dev_type in ('OPTIX', 'CUDA', 'HIP', 'ONEAPI', 'METAL'):
        try:
            cp.compute_device_type = dev_type
        except TypeError:
            continue
        try:
            cp.refresh_devices()
        except Exception:
            cp.get_devices()
        gpus = [d for d in cp.devices if d.type == dev_type]
        if gpus:
            for d in cp.devices:
                d.use = d.type == dev_type
            picked = dev_type
            break
    if picked:
        scene.cycles.device = 'GPU'
    else:
        cp.compute_device_type = 'NONE'
        scene.cycles.device = 'CPU'
    return picked


def world_studio(scene, color=(0.02, 0.02, 0.02), strength=1.0, hdri=None, hdri_strength=0.4, hdri_rot=0.0,
                 bg_visible=False):
    w = bpy.data.worlds.new('World_' + scene.name)
    scene.world = w
    w.use_nodes = True
    nt = w.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new('ShaderNodeOutputWorld')
    bg = nt.nodes.new('ShaderNodeBackground')
    bg.name = 'world_bg'
    bg.inputs['Color'].default_value = (*color[:3], 1)
    bg.inputs['Strength'].default_value = strength
    if hdri and os.path.exists(hdri):
        tc = nt.nodes.new('ShaderNodeTexCoord')
        mp = nt.nodes.new('ShaderNodeMapping')
        mp.inputs['Rotation'].default_value = (0, 0, hdri_rot)
        env = nt.nodes.new('ShaderNodeTexEnvironment')
        env.image = bpy.data.images.load(hdri, check_existing=True)
        bg.inputs['Strength'].default_value = hdri_strength
        nt.links.new(tc.outputs['Generated'], mp.inputs['Vector'])
        nt.links.new(mp.outputs[0], env.inputs['Vector'])
        nt.links.new(env.outputs['Color'], bg.inputs['Color'])
    # camera rays see a flat colour; lighting comes from env
    lp = nt.nodes.new('ShaderNodeLightPath')
    flat = nt.nodes.new('ShaderNodeBackground')
    flat.name = 'world_cam'
    flat.inputs['Color'].default_value = (*color[:3], 1)
    flat.inputs['Strength'].default_value = 1.0
    mix = nt.nodes.new('ShaderNodeMixShader')
    nt.links.new(lp.outputs['Is Camera Ray'], mix.inputs[0])
    nt.links.new(bg.outputs[0], mix.inputs[1])
    nt.links.new(flat.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs[0])
    return w
