"""Green Gate - 60 s commercial scene builder (Blender 4.5 LTS / 5.x).

blender -b --factory-startup --python build_commercial.py -- [--save out.blend] [--res 1920x1080]
        [--samples 96] [--cpu] [--frames 1,120,400] [--out frames/####] [--render]
"""
import bpy, sys, os, math, json
from mathutils import Vector
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gg_lib as G

FPS, END = 24, 1440
BEAT = 14  # frames per beat (102.86 bpm) - every cut lands on a beat
SHOTS = {  # name: (first, last) frame, inclusive
    'reveal': (1, 98), 'wake': (99, 196), 'browse': (197, 336),
    'p_watch': (337, 392), 'p_perfume': (393, 448), 'p_earbuds': (449, 504),
    'p_sun': (505, 560), 'p_candle': (561, 616), 'p_serum': (617, 672),
    'cart': (673, 812), 'checkout': (813, 952), 'drop': (953, 1050), 'delivered': (1051, 1176),
    'hero': (1177, 1316), 'endcard': (1317, 1440),
}
SET_X = {'dark': 0, 'p_watch': 40, 'p_perfume': 80, 'p_earbuds': 120, 'p_sun': 160, 'p_candle': 200,
         'p_serum': 240, 'light': 300, 'delivery': 340, 'hero': 380, 'end': 420}


def arg(name, default=None, cast=str):
    a = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
    if name in a:
        i = a.index(name)
        if i + 1 < len(a) and not a[i + 1].startswith('--'):
            return cast(a[i + 1])
        return True
    return default


# ------------------------------------------------------------------ animation helpers
def fc_for(idblock, data_path, index=-1):
    for fc in G.all_fcurves(idblock):
        if fc.data_path == data_path and (index < 0 or fc.array_index == index):
            yield fc


def set_interp(idblock, data_path, frame, interp):
    for fc in fc_for(idblock, data_path):
        for kp in fc.keyframe_points:
            if abs(kp.co.x - frame) < 1e-3:
                kp.interpolation = interp


def key(obj, prop, frame, value, interp=None):
    setattr(obj, prop, value)
    obj.keyframe_insert(prop, frame=frame)
    if interp:
        set_interp(obj, prop, frame, interp)


def key_loc(o, frame, loc, interp=None):
    key(o, 'location', frame, Vector(loc), interp)


def key_rot(o, frame, rot_deg, interp=None):
    key(o, 'rotation_euler', frame, [math.radians(r) for r in rot_deg], interp)


def key_socket(idtree, sock, frame, value, interp=None):
    sock.default_value = value
    sock.keyframe_insert('default_value', frame=frame)
    if interp:
        set_interp(idtree, sock.path_from_id('default_value'), frame, interp)


def add_noise(o, prop, strength, scale=40.0, phase=0.0):
    for fc in fc_for(o, prop):
        m = fc.modifiers.new('NOISE')
        m.strength = strength
        m.scale = scale
        m.phase = phase + fc.array_index * 13.7
        m.blend_in = 0


def visible_only(objs, ranges):
    """Render-visibility keyed so objects exist only inside the given frame ranges."""
    for o in objs:
        o.hide_render = True
        o.keyframe_insert('hide_render', frame=0)
        for a, b in ranges:
            o.hide_render = False
            o.keyframe_insert('hide_render', frame=a)
            o.hide_render = True
            o.keyframe_insert('hide_render', frame=b + 1)
        for fc in fc_for(o, 'hide_render'):
            for kp in fc.keyframe_points:
                kp.interpolation = 'CONSTANT'


def coll_objects(c):
    out = list(c.objects)
    for ch in c.children:
        out += coll_objects(ch)
    return out


# ------------------------------------------------------------------ rig helpers
def shot_camera(name, set_x, frames, cam_keys, tgt_keys, lens=85, fstop=4.0, shake=0.0003, sensor=36):
    """cam_keys / tgt_keys: list of (frame, (x,y,z) local to set)."""
    tgt = G.empty(name + '_Target')
    cam = G.camera(name, Vector(cam_keys[0][1]) + Vector((set_x, 0, 0)), Vector(tgt_keys[0][1]) + Vector((set_x, 0, 0)),
                   lens=lens, fstop=fstop, focus=tgt, sensor=sensor)
    c = cam.constraints.new('TRACK_TO')
    c.target = tgt
    c.track_axis = 'TRACK_NEGATIVE_Z'
    c.up_axis = 'UP_Y'
    for f, p in cam_keys:
        key_loc(cam, f, Vector(p) + Vector((set_x, 0, 0)))
    for f, p in tgt_keys:
        key_loc(tgt, f, Vector(p) + Vector((set_x, 0, 0)))
    if shake:
        d = (Vector(cam_keys[0][1]) - Vector(tgt_keys[0][1])).length
        add_noise(cam, 'location', shake * d, 55.0, phase=hash(name) % 100)
    m = bpy.context.scene.timeline_markers.new(name, frame=frames[0])
    m.camera = cam
    return cam, tgt


def lights_rig(set_x, spec):
    """spec: list of dicts {name, loc, target, size, irr, color, shape, spread}"""
    out = []
    for s in spec:
        loc = Vector(s['loc']) + Vector((set_x, 0, 0))
        tgt = Vector(s.get('target', (0, 0, 0.05))) + Vector((set_x, 0, 0))
        o = G.area_light_irr(s['name'], loc, tgt, s.get('size', (0.5, 0.5)), s.get('irr', 2.0),
                             color=s.get('color', (1, 1, 1)), shape=s.get('shape', 'RECTANGLE'),
                             spread=s.get('spread', 180))
        out.append(o)
    return out


def kelvin(k):
    # approximate blackbody -> linear rgb (normalised)
    t = k / 100.0
    r = 255 if t <= 66 else 329.698727446 * ((t - 60) ** -0.1332047592)
    g = 99.4708025861 * math.log(t) - 161.1195681661 if t <= 66 else 288.1221695283 * ((t - 60) ** -0.0755148492)
    b = 255 if t >= 66 else (0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307)
    c = [max(0, min(255, v)) / 255 for v in (r, g, b)]
    lin = [G.srgb_to_lin(v) for v in c]
    m = max(lin)
    return tuple(v / m for v in lin)


def drop_keys(o, X, f0, h, slowmo=2.0, restitution=0.17):
    g = 9.81 / (slowmo * slowmo)
    t_fall = math.sqrt(2 * h / g)
    n = int(math.ceil(t_fall * FPS))
    yaw0, yaw1 = 15.0, 9.5
    for i in range(n + 1):
        t = min(i / FPS, t_fall)
        k = t / t_fall
        key_loc(o, f0 + i, (X, 0.0, max(h - 0.5 * g * t * t, 0.0)), 'LINEAR')
        key_rot(o, f0 + i, (5.0 * (1 - k), -4.0 * (1 - k), yaw0 + (yaw1 + 0.6 - yaw0) * k), 'LINEAR')
    vb = restitution * g * t_fall
    nb = int(round(2 * vb / g * FPS))
    for j in range(1, nb + 1):
        t = j / FPS
        z = max(vb * t - 0.5 * g * t * t, 0.0)
        w = math.sin(math.pi * j / nb)
        key_loc(o, f0 + n + j, (X, 0.0, z), 'LINEAR')
        key_rot(o, f0 + n + j, (-0.9 * w, 0.6 * w, yaw1 + 0.6 - 0.6 * j / nb), 'LINEAR')
    key_loc(o, f0 + n + nb + 3, (X, 0.0, 0.0))
    key_rot(o, f0 + n + nb + 3, (0, 0, yaw1))
    return f0 + n


def build_stand(name, parent=None):
    """Minimal brushed-aluminium desk stand; phone leans back 20 deg."""
    root = G.empty(name)
    if parent:
        root.parent = parent
    alu = G.mat_metal('Aluminium_Brushed', G.hexc('#c9cacc'), rough=0.3, aniso=0.5, brushed=True)
    G.box_obj(name + '_Base', 0.072, 0.095, 0.0045, alu, root, bevel=0.0015, seg=4, loc=(0, 0.01, 0.00225))
    back = G.box_obj(name + '_Back', 0.050, 0.0045, 0.092, alu, root, bevel=0.0015, seg=4)
    back.rotation_euler = (math.radians(-20), 0, 0)
    back.location = (0, 0.024 + 0.046 * math.sin(math.radians(20)), 0.0045 + 0.046 * math.cos(math.radians(20)))
    G.box_obj(name + '_Lip', 0.072, 0.008, 0.013, alu, root, bevel=0.0012, seg=4, loc=(0, -0.026, 0.011))
    return root


def phone_on_stand(name, screen_mat, x, y, yaw=0.0, frame_color='#8c877f'):
    st = build_stand(name + '_Stand')
    st.location = (x, y, 0)
    st.rotation_euler = (0, 0, math.radians(yaw))
    ph, disp = G.build_phone(name, frame_color=frame_color)
    disp.data.materials.append(screen_mat)
    ph.parent = st
    # bottom edge rests on lip shelf, back against the support (leaning 20 deg)
    ph.rotation_euler = (math.radians(-20), 0, 0)
    ph.location = (0, -0.0185 + 0.0738 * math.sin(math.radians(20)), 0.0085 + 0.0738 * math.cos(math.radians(20)))
    return st, ph


# ------------------------------------------------------------------ screen program
def build_screen(meta):
    sp = meta['home']
    layers = [
        dict(key='splash', file='splash.png'),
        dict(key='home', file='home_tall.png', height_px=int(round(sp['height_pt'] * 3)),
             sticky_px=int(round((meta['status_pt'] + sp['header_pt']) * 3))),
        dict(key='pdp', file='pdp_tall.png', height_px=int(round(meta['pdp']['height_pt'] * 3)),
             sticky_px=int(round((meta['status_pt'] + sp['header_pt']) * 3))),
        dict(key='added', file='pdp_added.png'),
        dict(key='checkout', file='checkout.png'),
        dict(key='order', file='order.png'),
    ]
    mat = G.screen_material('Screen_UI', layers, chrome='chrome.png')
    nt = mat.node_tree
    N = nt.nodes
    keys = [L['key'] for L in layers]

    def op(k, f, v, interp='CONSTANT'):
        key_socket(nt, N[k + '_op'].outputs[0], f, v, interp)

    def show_only(k, f):
        for kk in keys:
            op(kk, f, 1.0 if kk == k else 0.0)

    def fade(k_from, k_to, f0, f1):
        # bring k_to in over (f0..f1); then drop k_from
        op(k_to, f0, 0.0, 'BEZIER')
        op(k_to, f1, 1.0, 'CONSTANT')
        op(k_from, f1 + 1, 0.0, 'CONSTANT')

    def scroll(k, f, px, interp='BEZIER'):
        mp = N[k + '_map']
        Hpx = mp['height_px']
        sock = mp.inputs['Location']
        key_socket(nt, sock, f, (0, 1 - (px + 2556) / Hpx, 0), interp)

    pw = N['screen_power'].outputs[0]
    key_socket(nt, pw, 0, 0.0, 'CONSTANT')
    key_socket(nt, pw, 150, 0.0, 'BEZIER')
    key_socket(nt, pw, 158, 1.0, 'CONSTANT')
    key_socket(nt, pw, 673, 1.3, 'CONSTANT')
    key_socket(nt, pw, 953, 1.15, 'CONSTANT')
    key_socket(nt, pw, 1177, 1.0, 'CONSTANT')

    show_only('splash', 0)
    scroll('home', 0, 0, 'CONSTANT')
    fade('splash', 'home', 176, 186)
    scroll('home', 214, 0)
    end_px = min(1350 * 3, sp['height_pt'] * 3 - 2556)
    scroll('home', 330, end_px)
    scroll('home', 336, end_px, 'CONSTANT')
    # cart sequence (pdp scrolls to the button, toast, cart drawer)
    show_only('pdp', 673)
    scroll('pdp', 673, 0, 'CONSTANT')
    scroll('pdp', 692, 0)
    scroll('pdp', 740, meta['pdp']['scroll_pt'] * 3)
    fade('pdp', 'added', 758, 761)
    show_only('checkout', 813)
    fade('checkout', 'order', 878, 888)
    show_only('order', 953)
    show_only('home', 1177)
    scroll('home', 1177, 760 * 3, 'CONSTANT')
    return mat


# ------------------------------------------------------------------ sets
def set_dark(screen_mat, hdri):
    X = SET_X['dark']
    c = G.collection('Set_Dark')
    G.set_collection(c)
    floor_m = G.principled('Dark_Floor', (0.010, 0.011, 0.011, 1), rough=0.16, spec=0.5)
    G.add_noise_rough(floor_m, 0.16, 0.07, scale=3, detail=8)
    G.cyclorama('Dark_Cyc', None, size=3.2, height=2.0, radius=0.5, mat=floor_m, loc=(X, -0.6, 0))
    ph, disp = G.build_phone('Phone_Dark', frame_color='#8c877f', back_color='#26282a')
    disp.data.materials.append(screen_mat)
    ph.location = (X, 0, 0.085)
    # S1 back to camera, S2 turns to the front, S3 slight tilt toward camera
    key_rot(ph, 1, (0, 0, 180 + 18))
    key_rot(ph, 98, (0, 0, 180 + 10))
    key_rot(ph, 112, (0, 0, 180 + 8))
    key_rot(ph, 176, (0, 0, -6))
    key_rot(ph, 196, (0, 0, -10))
    key_rot(ph, 206, (-4, 0, -14))
    key_rot(ph, 336, (-4, 0, -22))
    key_loc(ph, 99, (X, 0, 0.080))
    key_loc(ph, 196, (X, 0, 0.086))
    key_loc(ph, 336, (X, 0, 0.082))
    ls = lights_rig(X, [
        dict(name='D_Sweep', loc=(-0.9, -0.45, 0.19), target=(0, 0, 0.09), size=(0.025, 1.2), irr=26.0, spread=60),
        dict(name='D_RimL', loc=(-0.42, 0.30, 0.17), target=(0, 0, 0.085), size=(0.05, 0.9), irr=7.0, spread=70),
        dict(name='D_RimR', loc=(0.42, 0.30, 0.17), target=(0, 0, 0.085), size=(0.05, 0.9), irr=7.0, spread=70),
        dict(name='D_Top', loc=(0, -0.1, 1.1), target=(0, 0, 0.08), size=(0.9, 0.6), irr=0.6),
        dict(name='D_Front', loc=(-0.6, -0.9, 0.35), target=(0, 0, 0.085), size=(0.8, 0.8), irr=0.35),
        dict(name='D_Glow', loc=(0, 0.45, 0.04), target=(0, 1.0, 0.45), size=(1.4, 0.3), irr=2.2, color=G.GREEN[:3]),
    ])
    sweep = ls[0]
    key_loc(sweep, 1, (X - 0.9, -0.45, 0.19))
    key_loc(sweep, 94, (X + 0.9, -0.45, 0.19))
    for f, e in ((0, 1.0), (98, 1.0), (99, 0.0)):
        key(sweep.data, 'energy', f, sweep.data.energy * e, 'CONSTANT')
    for L in ls[1:]:
        base = L.data.energy
        key(L.data, 'energy', 0, base * 0.12, 'CONSTANT')
        key(L.data, 'energy', 82, base * 0.12)
        key(L.data, 'energy', 112, base)
    cam1, _ = shot_camera('Cam_Reveal', X, SHOTS['reveal'],
                          [(1, (-0.075, -0.205, 0.185)), (98, (-0.040, -0.150, 0.162))],
                          [(1, (-0.012, -0.008, 0.136)), (98, (-0.010, -0.008, 0.134))], lens=100, fstop=2.8)
    cam2, _ = shot_camera('Cam_Wake', X, SHOTS['wake'],
                          [(99, (0.10, -0.95, 0.15)), (196, (0.03, -0.78, 0.11))],
                          [(99, (0, 0, 0.088)), (196, (0, 0, 0.088))], lens=85, fstop=4.0)
    cam3, _ = shot_camera('Cam_Browse', X, SHOTS['browse'],
                          [(197, (-0.26, -0.53, 0.15)), (336, (-0.13, -0.57, 0.12))],
                          [(197, (-0.05, 0, 0.090)), (336, (-0.045, 0, 0.088))], lens=70, fstop=4.5)
    return c


def product_set(key_name, builder, backdrop_hex, plinth_kind, plinth_hex, cam, tgt, lights, lens=100, fstop=5.6,
                spin=(-10, 6), product_z=None, extra=None, floor_rough=None):
    X = SET_X[key_name]
    c = G.collection('Set_' + key_name)
    G.set_collection(c)
    if floor_rough is None:
        G.cyclorama(key_name + '_Cyc', G.hexc(backdrop_hex), size=4, height=2.5, radius=0.6, loc=(X, 0.7, 0))
    else:
        m = G.principled(key_name + '_CycMat', G.hexc(backdrop_hex), rough=floor_rough, spec=0.5)
        G.add_noise_rough(m, floor_rough, 0.05, scale=4)
        G.cyclorama(key_name + '_Cyc', None, size=4, height=2.5, radius=0.6, mat=m, loc=(X, 0.7, 0))
    kind, dims = plinth_kind
    if kind == 'travertine':
        pm = G.mat_plaster('Travertine', G.hexc(plinth_hex), rough=0.7)
        G.add_bump(pm, 0.35, 60, 2, kind='voronoi')
    elif kind == 'gloss':
        pm = G.principled(key_name + '_Gloss', G.hexc(plinth_hex), rough=0.08, coat=1.0, coat_rough=0.02)
    else:
        pm = G.mat_plaster('Plaster_' + plinth_hex, G.hexc(plinth_hex))
    top = 0.0
    for (r, h, ox, oy, square) in dims:
        G.plinth(key_name + '_Plinth', r, h, pm, loc=(X + ox, oy, 0), square=square)
        top = max(top, h)
    prod = builder()
    rx = math.degrees(prod.rotation_euler.x)
    prod.location = (X, 0, (product_z if product_z is not None else top) + prod.location.z)
    key_rot(prod, SHOTS[key_name][0], (rx, 0, spin[0]))
    key_rot(prod, SHOTS[key_name][1], (rx, 0, spin[1]))
    if extra:
        extra(X, top)
    lights_rig(X, lights)
    shot_camera('Cam_' + key_name, X, SHOTS[key_name],
                [(SHOTS[key_name][0], cam[0]), (SHOTS[key_name][1], cam[1])],
                [(SHOTS[key_name][0], tgt[0]), (SHOTS[key_name][1], tgt[1])], lens=lens, fstop=fstop)
    return c


def soft3(top, key_irr=3.0, warm=5200, rim=6.0):
    k = kelvin(warm)
    return [
        dict(name='K', loc=(-0.45, -0.45, top + 0.45), target=(0, 0, top + 0.03), size=(0.6, 0.6), irr=key_irr, color=k),
        dict(name='F', loc=(0.6, -0.5, top + 0.15), target=(0, 0, top + 0.03), size=(0.7, 0.7), irr=key_irr * 0.3),
        dict(name='R', loc=(0.35, 0.40, top + 0.25), target=(0, 0, top + 0.04), size=(0.04, 0.6), irr=rim, spread=60),
        dict(name='R2', loc=(-0.35, 0.40, top + 0.25), target=(0, 0, top + 0.04), size=(0.04, 0.6), irr=rim * 0.7, spread=60),
        dict(name='B', loc=(0, 0.25, 0.05), target=(0, 0.7, 0.5), size=(1.2, 0.3), irr=1.6, color=k),
    ]


def set_products():
    cs = []
    t = 0.06
    cs.append(product_set('p_watch', G.build_watch, '#a9b8a6', ('plaster', [(0.075, t, 0, 0, False)]), '#ebe7df',
                          cam=((-0.16, -0.36, t + 0.11), (-0.10, -0.31, t + 0.085)),
                          tgt=((0, 0, t + 0.032), (0, 0, t + 0.033)), lights=soft3(t, 3.2), spin=(-24, -8)))
    t = 0.07
    cs.append(product_set('p_perfume', G.build_perfume, '#d6c3a8', ('travertine', [(0.065, t, 0, 0, True)]), '#e3d6c2',
                          cam=((0.13, -0.56, t + 0.07), (0.08, -0.52, t + 0.085)),
                          tgt=((0, 0, t + 0.05), (0, 0, t + 0.055)),
                          lights=soft3(t, 2.4, 4800, rim=9.0) + [dict(name='Back', loc=(0.02, 0.35, t + 0.06),
                                                                     target=(0, 0, t + 0.05), size=(0.18, 0.25), irr=14.0,
                                                                     color=kelvin(3800))],
                          spin=(-20, -32)))
    t = 0.035
    cs.append(product_set('p_earbuds', G.build_earbuds_case, '#2b2e2d', ('gloss', [(0.065, t, 0, 0, False)]), '#111312',
                          cam=((-0.18, -0.30, t + 0.09), (-0.08, -0.32, t + 0.07)),
                          tgt=((0, 0, t + 0.024), (0, 0, t + 0.022)),
                          lights=soft3(t, 3.0, 6000, rim=10.0), spin=(-30, -12), floor_rough=0.3))
    t = 0.05

    def sun_extra(X, top):
        sun = bpy.data.lights.new('Sun_Hard', 'SUN')
        sun.energy = 4.2
        sun.angle = math.radians(1.2)
        sun.color = kelvin(4300)
        o = bpy.data.objects.new('Sun_Hard', sun)
        G.link(o)
        o.location = (X, 0, 1)
        o.rotation_euler = (math.radians(52), math.radians(-18), math.radians(-38))
        o['set_x'] = X
    cs.append(product_set('p_sun', G.build_sunglasses, '#d4977a', ('travertine', [(0.10, t, 0, 0.0, True)]), '#e8dccb',
                          cam=((0.29, -0.48, t + 0.14), (0.19, -0.45, t + 0.11)),
                          tgt=((0, 0.03, t + 0.02), (0, 0.035, t + 0.02)),
                          lights=soft3(t, 0.8, 5000, rim=3.0), spin=(14, 4), extra=sun_extra))
    t = 0.045
    cs.append(product_set('p_candle', G.build_candle, '#e6dccb', ('plaster', [(0.07, t, 0, 0, False)]), '#f1ece4',
                          cam=((-0.15, -0.60, t + 0.16), (-0.08, -0.56, t + 0.13)),
                          tgt=((0, 0, t + 0.045), (0, 0, t + 0.045)),
                          lights=soft3(t, 2.6, 3600, rim=7.0), spin=(-12, 4)))
    t = 0.08

    def lip_extra(X, top):
        pm = bpy.data.materials.get('Plaster_#dfe6dc')
        G.plinth('p_serum_Plinth2', 0.05, 0.045, pm, loc=(X + 0.085, -0.04, 0))
        lp = G.build_lipstick('Lipstick_Hero')
        lp.location = (X + 0.085, -0.04, 0.045)
        lp.rotation_euler = (0, 0, math.radians(-25))
    cs.append(product_set('p_serum', G.build_serum, '#c7d6c6', ('plaster', [(0.06, t, 0, 0, False)]), '#dfe6dc',
                          cam=((0.035, -0.64, t + 0.10), (0.055, -0.59, t + 0.09)),
                          tgt=((0.052, 0, t + 0.045), (0.055, 0, t + 0.045)),
                          lights=soft3(t, 2.8, 5600, rim=7.0), spin=(-8, 10), extra=lip_extra, fstop=7.1))
    return cs


def set_light(screen_mat):
    X = SET_X['light']
    c = G.collection('Set_Light')
    G.set_collection(c)
    m = G.principled('White_Studio', G.hexc('#eceeec'), rough=0.42, spec=0.5)
    G.add_noise_rough(m, 0.42, 0.06, scale=5)
    G.cyclorama('Light_Cyc', None, size=6, height=3, radius=0.9, mat=m, loc=(X, 1.0, 0))
    st, ph = phone_on_stand('Phone_Light', screen_mat, X, 0, yaw=-14)
    flat, disp = G.build_phone('Phone_Flat', frame_color='#8c877f')
    disp.data.materials.append(screen_mat)
    tilt = math.degrees(math.atan(0.0037 / 0.125))
    flat.rotation_euler = (math.radians(-90 + tilt), 0, math.radians(8))
    flat.location = (X + 0.6, 0, G.PHONE['D'] / 2 + 0.0019)
    lights_rig(X, [
        dict(name='L_Key', loc=(-0.7, -0.6, 0.9), target=(0, 0, 0.08), size=(1.0, 1.0), irr=2.6, color=kelvin(5600)),
        dict(name='L_Fill', loc=(0.8, -0.5, 0.4), target=(0, 0, 0.08), size=(1.0, 1.0), irr=0.9),
        dict(name='L_Rim', loc=(0.3, 0.5, 0.35), target=(0, 0, 0.08), size=(0.05, 0.8), irr=6.0, spread=60),
        dict(name='L_Over', loc=(0.0, 0.35, 0.95), target=(0.6, 0, 0), size=(1.0, 0.8), irr=2.4),
    ])
    # black flags just off camera: keep the white studio from veiling the screen glass
    flag = G.principled('Flag_Black', (0.002, 0.002, 0.002, 1), rough=0.9, spec=0.0)
    f1 = G.plane_obj('Flag_Cart', 1.4, 0.9, flag, plane='XY')
    f1.location = (X + 0.55, -1.25, 0.35)
    G.aim(f1, (X, 0, 0.09))
    f2 = G.plane_obj('Flag_Over', 0.9, 0.9, flag, plane='XY')
    f2.location = (X + 0.52, -0.25, 0.75)
    shot_camera('Cam_Cart', X, SHOTS['cart'],
                [(673, (0.27, -0.70, 0.20)), (812, (0.19, -0.66, 0.17))],
                [(673, (-0.075, -0.012, 0.085)), (812, (-0.070, -0.012, 0.088))], lens=85, fstop=4.0)
    shot_camera('Cam_Checkout', X, SHOTS['checkout'],
                [(813, (0.6 - 0.05, -0.13, 0.50)), (952, (0.6 - 0.06, -0.11, 0.46))],
                [(813, (0.6 - 0.085, 0.0, 0.0)), (952, (0.6 - 0.083, 0.004, 0.0))], lens=50, fstop=5.6)
    return c


def set_delivery(screen_mat):
    X = SET_X['delivery']
    c = G.collection('Set_Delivery')
    G.set_collection(c)
    fm = G.principled('Concrete_Warm', G.hexc('#b7aea3'), rough=0.75)
    G.add_bump(fm, 0.08, 25, 10)
    G.add_noise_rough(fm, 0.7, 0.12, scale=2)
    G.cyclorama('Del_Cyc', None, size=6, height=3, radius=0.9, mat=fm, loc=(X, 1.2, 0))
    box = G.build_shipping_box('ShipBox')
    box.location = (X, 0, 0)
    drop_keys(box, X, 953, 0.42)
    bag = G.build_paper_bag('Bag')
    bag.location = (X - 0.30, 0.06, 0)
    bag.rotation_euler = (0, 0, math.radians(12))
    ph = G.build_phone('Phone_Del')
    ph[1].data.materials.append(screen_mat)
    p = ph[0]
    p.rotation_euler = (math.radians(-17), 0, math.radians(9.5))
    p.location = (X + 0.05, -0.131, 0.0706)
    visible_only([o for o in [bag] + list(bag.children_recursive)], [SHOTS['delivered']])
    visible_only([o for o in [p] + list(p.children_recursive)], [SHOTS['delivered']])
    warm = kelvin(4200)
    lights_rig(X, [
        dict(name='Del_Key', loc=(-1.1, -0.7, 1.3), target=(0, 0, 0.1), size=(0.5, 0.5), irr=4.5, color=warm),
        dict(name='Del_Fill', loc=(1.0, -0.9, 0.5), target=(0, 0, 0.1), size=(1.2, 1.2), irr=0.8, color=kelvin(6500)),
        dict(name='Del_Rim', loc=(0.6, 0.6, 0.5), target=(0, 0, 0.1), size=(0.08, 1.0), irr=5.0, spread=70, color=warm),
        dict(name='Del_Bg', loc=(0, 0.6, 0.05), target=(0, 1.2, 0.6), size=(2.0, 0.4), irr=1.0, color=warm),
    ])
    shot_camera('Cam_Drop', X, SHOTS['drop'],
                [(953, (-0.30, -0.78, 0.10)), (1050, (-0.22, -0.66, 0.09))],
                [(953, (0, 0, 0.10)), (1050, (0, 0, 0.08))], lens=50, fstop=4.0)
    shot_camera('Cam_Delivered', X, SHOTS['delivered'],
                [(1051, (0.26, -0.82, 0.24)), (1176, (0.12, -0.80, 0.22))],
                [(1051, (-0.06, 0, 0.10)), (1176, (-0.08, 0, 0.10))], lens=50, fstop=5.6)
    return c


def set_hero(screen_mat):
    X = SET_X['hero']
    c = G.collection('Set_Hero')
    G.set_collection(c)
    bm = G.principled('Hero_Back', G.hexc('#173d26'), rough=0.85, spec=0.3)
    G.cyclorama('Hero_Cyc', None, size=6, height=3, radius=1.0, mat=bm, loc=(X, 1.0, 0))
    pl = G.mat_plaster('Plaster_Hero', G.hexc('#e7e2d8'))
    tv = G.mat_plaster('Travertine', G.hexc('#e3d6c2'))
    G.plinth('Hero_P0', 0.085, 0.07, pl, loc=(X, 0.02, 0))
    st, ph = phone_on_stand('Phone_Hero', screen_mat, X, 0.02, yaw=0)
    st.location.z = 0.07
    items = [
        (G.build_perfume, (-0.20, 0.10), 0.12, 0.06, True, -18, tv),
        (G.build_watch, (-0.13, -0.10), 0.04, 0.065, False, 20, pl),
        (G.build_serum, (-0.30, -0.02), 0.08, 0.04, False, 10, pl),
        (G.build_earbuds_case, (0.15, -0.09), 0.035, 0.05, False, -25, pl),
        (G.build_sunglasses, (0.26, 0.04), 0.09, 0.08, True, -30, tv),
        (G.build_candle, (0.16, 0.16), 0.13, 0.055, False, 10, pl),
        (G.build_lipstick, (-0.05, -0.17), 0.02, 0.03, False, 30, pl),
    ]
    for i, (fn, (x, y), h, r, sq, yaw, m) in enumerate(items):
        G.plinth('Hero_P%d' % (i + 1), r, h, m, loc=(X + x, y, 0), square=sq)
        o = fn()
        o.location = (X + x, y, h + (o.location.z if fn is G.build_sunglasses else 0))
        o.rotation_euler.z = math.radians(yaw)
    k = kelvin(4800)
    lights_rig(X, [
        dict(name='H_Key', loc=(-0.9, -0.8, 1.0), target=(0, 0, 0.1), size=(0.9, 0.9), irr=3.2, color=k),
        dict(name='H_Fill', loc=(1.0, -0.7, 0.5), target=(0, 0, 0.1), size=(1.0, 1.0), irr=0.8),
        dict(name='H_RimL', loc=(-0.6, 0.6, 0.5), target=(0, 0, 0.1), size=(0.06, 1.0), irr=6.0, spread=70),
        dict(name='H_RimR', loc=(0.6, 0.6, 0.5), target=(0, 0, 0.1), size=(0.06, 1.0), irr=6.0, spread=70),
        dict(name='H_Bg', loc=(0, 0.7, 0.05), target=(0, 1.0, 0.8), size=(2.2, 0.5), irr=2.0, color=G.GREEN[:3]),
    ])
    shot_camera('Cam_Hero', X, SHOTS['hero'],
                [(1177, (0.05, -0.95, 0.30)), (1316, (0.02, -0.80, 0.26))],
                [(1177, (0, 0, 0.11)), (1316, (0, 0, 0.115))], lens=40, fstop=6.3)
    return c


def set_end():
    X = SET_X['end']
    c = G.collection('Set_End')
    G.set_collection(c)
    bm = G.principled('End_Back', G.hexc('#0f3a20'), rough=0.6, spec=0.4)
    G.add_noise_rough(bm, 0.6, 0.1, scale=3)
    G.cyclorama('End_Cyc', None, size=6, height=3, radius=1.0, mat=bm, loc=(X, 0.6, 0))
    tile_m = G.principled('Icon_Green', G.GREEN, rough=0.22, coat=1.0, coat_rough=0.03)
    nt = tile_m.node_tree
    t = G.image_node(nt, G.tex_path('gate_white.png'), extension='CLIP')
    tc = nt.nodes.new('ShaderNodeTexCoord')
    mp = nt.nodes.new('ShaderNodeMapping')
    S = 0.12
    mp.inputs['Scale'].default_value = (1 / (S * 0.62), 1 / (S * 0.62), 1)
    mp.inputs['Location'].default_value = (0.5, 0.5, 0)
    sxz = nt.nodes.new('ShaderNodeSeparateXYZ')
    cxz = nt.nodes.new('ShaderNodeCombineXYZ')
    nt.links.new(tc.outputs['Object'], sxz.inputs[0])
    nt.links.new(sxz.outputs['X'], cxz.inputs['X'])
    nt.links.new(sxz.outputs['Z'], cxz.inputs['Y'])
    nt.links.new(cxz.outputs[0], mp.inputs['Vector'])
    nt.links.new(mp.outputs[0], t.inputs['Vector'])
    mix = nt.nodes.new('ShaderNodeMix')
    mix.data_type = 'RGBA'
    mix.inputs[6].default_value = G.GREEN
    mix.inputs[7].default_value = (0.92, 0.93, 0.92, 1)
    sep = nt.nodes.new('ShaderNodeSeparateXYZ')
    front = nt.nodes.new('ShaderNodeMath')
    front.operation = 'LESS_THAN'
    front.inputs[1].default_value = -0.011
    mul = nt.nodes.new('ShaderNodeMath')
    mul.operation = 'MULTIPLY'
    nt.links.new(tc.outputs['Object'], sep.inputs[0])
    nt.links.new(sep.outputs['Y'], front.inputs[0])
    nt.links.new(front.outputs[0], mul.inputs[0])
    nt.links.new(t.outputs['Alpha'], mul.inputs[1])
    nt.links.new(mul.outputs[0], mix.inputs[0])
    nt.links.new(mix.outputs[2], G.bsdf(tile_m).inputs['Base Color'])
    bp = nt.nodes.new('ShaderNodeBump')
    bp.inputs['Strength'].default_value = 0.6
    bp.inputs['Distance'].default_value = 0.0008
    nt.links.new(mul.outputs[0], bp.inputs['Height'])
    nt.links.new(bp.outputs['Normal'], G.bsdf(tile_m).inputs['Normal'])
    icon = G.rounded_slab('App_Icon', S, S, 0.024, 0.027, 0.0045, tile_m, seg=18, edge_seg=6)
    icon.location = (X, 0, 0.30)
    key_loc(icon, 1317, (X, 0.02, 0.20))
    key_rot(icon, 1317, (12, 0, -38))
    key_loc(icon, 1358, (X, 0, 0.290))
    key_rot(icon, 1358, (0, 0, -3))
    key_loc(icon, 1440, (X, 0, 0.294))
    key_rot(icon, 1440, (0, 0, 2))
    lights_rig(X, [
        dict(name='E_Key', loc=(-0.6, -0.7, 0.8), target=(0, 0, 0.3), size=(0.8, 0.8), irr=1.1, color=kelvin(5600)),
        dict(name='E_Strip', loc=(0.5, -0.35, 0.5), target=(0, 0, 0.3), size=(0.04, 0.9), irr=3.5, spread=60),
        dict(name='E_Rim', loc=(0, 0.5, 0.7), target=(0, 0, 0.3), size=(0.6, 0.06), irr=3.0, spread=70),
        dict(name='E_Bg', loc=(0, 0.25, 0.02), target=(0, 0.6, 0.7), size=(2.0, 0.4), irr=2.2, color=kelvin(5000)),
    ])
    shot_camera('Cam_End', X, SHOTS['endcard'],
                [(1317, (0, -1.18, 0.29)), (1440, (0, -1.10, 0.29))],
                [(1317, (0, 0, 0.248)), (1440, (0, 0, 0.248))], lens=70, fstop=8.0, shake=0.0)
    return c


# ------------------------------------------------------------------ per-shot exposure / world
EXPOSURE = {'reveal': 0.65, 'wake': 0.2, 'browse': 0.1, 'p_watch': 0.0, 'p_perfume': 0.0, 'p_earbuds': 0.15,
            'p_sun': 0.0, 'p_candle': 0.0, 'p_serum': 0.0, 'cart': -0.65, 'checkout': -0.55, 'drop': 0.0,
            'delivered': 0.0, 'hero': 0.1, 'endcard': 0.0}
WORLD = {'reveal': 0.05, 'wake': 0.12, 'browse': 0.15, 'cart': 0.35, 'checkout': 0.35, 'hero': 0.25, 'endcard': 0.25}


def key_shots(sc):
    vs = sc.view_settings
    w = sc.world.node_tree.nodes['world_bg'].inputs['Strength']
    for name, (a, b) in SHOTS.items():
        vs.exposure = EXPOSURE.get(name, 0.0)
        vs.keyframe_insert('exposure', frame=a)
        key_socket(sc.world.node_tree, w, a, WORLD.get(name, 0.3), 'CONSTANT')
    for fc in fc_for(sc, 'view_settings.exposure'):
        for kp in fc.keyframe_points:
            kp.interpolation = 'CONSTANT'


def fade_io(sc):
    """Fade from/to black via film exposure is not available - use view exposure ramps."""
    vs = sc.view_settings
    for f, e in ((1, -6.0), (14, EXPOSURE['reveal'])):
        vs.exposure = e
        vs.keyframe_insert('exposure', frame=f)
    for f, e in ((1428, 0.0), (1440, -7.0)):
        vs.exposure = e
        vs.keyframe_insert('exposure', frame=f)
    for fc in fc_for(sc, 'view_settings.exposure'):
        for kp in fc.keyframe_points:
            kp.interpolation = 'LINEAR' if kp.co.x in (1, 1428) else 'CONSTANT'


# ------------------------------------------------------------------ main
def build(meta):
    G.clear_scene()
    sc = bpy.context.scene
    sc.name = 'GreenGate'
    sc.frame_start, sc.frame_end = 1, END
    res = arg('--res', '1920x1080')
    rx, ry = (int(v) for v in res.split('x'))
    G.setup_render(sc, (rx, ry), arg('--samples', 96, int), FPS, gpu=not arg('--cpu', False))
    hdri = os.path.join(G.ASSET_DIR, 'hdri', 'studio_small_09_2k.hdr')
    G.world_studio(sc, color=(0.004, 0.0045, 0.0042), strength=0.3, hdri=hdri, hdri_strength=0.3)
    screen = build_screen(meta)
    sets = {
        'dark': set_dark(screen, hdri),
        'light': set_light(screen),
        'delivery': set_delivery(screen),
        'hero': set_hero(screen),
        'end': set_end(),
    }
    for c in set_products():
        sets[c.name.replace('Set_', '')] = c
    G.set_collection(None)
    uses = {'dark': ['reveal', 'wake', 'browse'], 'light': ['cart', 'checkout'], 'delivery': ['drop', 'delivered'],
            'hero': ['hero'], 'end': ['endcard']}
    for k in SET_X:
        if k.startswith('p_'):
            uses[k] = [k]
    for k, c in sets.items():
        objs = [o for o in coll_objects(c) if o.type != 'CAMERA' and (not o.animation_data or not any(
            fc.data_path == 'hide_render' for fc in G.all_fcurves(o)))]
        visible_only(objs, [SHOTS[s] for s in uses[k]])
    key_shots(sc)
    fade_io(sc)
    sc.frame_set(1)
    return sc


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    meta = json.load(open(os.path.join(here, 'screens', 'screens.json')))
    sc = build(meta)
    save = arg('--save')
    if arg('--pack'):
        bpy.ops.file.pack_all()
    if save:
        bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(save), compress=True)
        print('SAVED', save)
    frames = arg('--frames')
    out = arg('--out', os.path.join(here, 'preview', 'f_####'))
    if frames:
        for f in [int(x) for x in str(frames).split(',')]:
            sc.frame_set(f)
            sc.render.filepath = out.replace('####', '%04d' % f)
            sc.render.image_settings.file_format = 'PNG'
            sc.render.image_settings.color_mode = 'RGB'
            bpy.ops.render.render(write_still=True)
            print('FRAME', f, sc.render.filepath)
    if arg('--render'):
        sc.render.filepath = out
        sc.render.image_settings.file_format = 'JPEG'
        sc.render.image_settings.color_mode = 'RGB'
        sc.render.image_settings.quality = 95
        sc.render.use_overwrite = False
        sc.render.use_placeholder = True
        bpy.ops.render.render(animation=True)


if __name__ == '__main__':
    main()
