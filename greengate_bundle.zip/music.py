"""Original 60 s soundtrack for the Green Gate commercial, locked to the edit.

python music.py out.wav      (needs numpy + scipy; both ship with Colab)
Beat = 14 video frames @ 24 fps (102.86 bpm). Every cut lands on a beat.
"""
import sys, wave
import numpy as np
from scipy import signal

SR = 48000
DUR = 60.0
BEAT = 14 / 24
N = int(SR * DUR)
rng = np.random.default_rng(7)
t_all = np.arange(N) / SR


def f2t(frame):  # video frame -> seconds
    return (frame - 1) / 24.0


def b2t(b):
    return b * BEAT


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


def place(buf, x, t0, gain=1.0):
    i0 = int(round(t0 * SR))
    if i0 >= len(buf):
        return
    i1 = min(len(buf), i0 + len(x))
    if i0 < 0:
        x = x[-i0:]
        i0 = 0
        i1 = min(len(buf), len(x))
    buf[i0:i1] += gain * x[:i1 - i0]


def lp(x, fc, order=2):
    b, a = signal.butter(order, min(fc / (SR / 2), 0.99), 'low')
    return signal.lfilter(b, a, x)


def hp(x, fc, order=2):
    b, a = signal.butter(order, fc / (SR / 2), 'high')
    return signal.lfilter(b, a, x)


def bp(x, f1, f2, order=2):
    b, a = signal.butter(order, [f1 / (SR / 2), f2 / (SR / 2)], 'band')
    return signal.lfilter(b, a, x)


def saw(freq, n, detune_cents=0.0, phase=0.0):
    f = freq * 2 ** (detune_cents / 1200)
    ph = (np.arange(n) * f / SR + phase) % 1.0
    return 2 * ph - 1


def env_adsr(n, a, d, s, r):
    e = np.ones(n) * s
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na = min(na, n)
    e[:na] = np.linspace(0, 1, na, endpoint=False)
    nd = min(nd, n - na)
    e[na:na + nd] = np.linspace(1, s, nd, endpoint=False)
    if nr > 0:
        e[-nr:] *= np.linspace(1, 0, nr)
    return e


# ------------------------------------------------------------------ instruments
def pad_chord(notes, dur, cutoff=1400):
    n = int(dur * SR)
    x = np.zeros(n)
    for m in notes:
        for dc, ph in ((-7, 0.1), (0, 0.5), (6, 0.8)):
            x += saw(midi(m), n, dc, ph)
    x = lp(x / (len(notes) * 3), cutoff, 2)
    return x * env_adsr(n, 0.6, 0.4, 0.85, 0.7)


def kick(level=1.0):
    n = int(0.45 * SR)
    t = np.arange(n) / SR
    f = 44 + 90 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    body = np.sin(ph) * np.exp(-t / 0.17)
    click = hp(rng.standard_normal(n), 2500) * np.exp(-t / 0.003) * 0.25
    return level * np.tanh(1.6 * (body + click)) * 0.9


def snap(level=1.0):
    n = int(0.25 * SR)
    t = np.arange(n) / SR
    x = np.zeros(n)
    for k, d in enumerate((0, 0.009, 0.019)):
        i = int(d * SR)
        x[i:] += np.exp(-(t[:n - i]) / (0.012 if k < 2 else 0.07))
    return level * bp(rng.standard_normal(n), 900, 5200) * x * 0.5


def hat(level=1.0, open_=False):
    n = int((0.22 if open_ else 0.06) * SR)
    t = np.arange(n) / SR
    return level * hp(rng.standard_normal(n), 7000, 3) * np.exp(-t / (0.07 if open_ else 0.014)) * 0.35


def bass_note(m, dur, level=1.0):
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = midi(m)
    x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t) + 0.12 * saw(f, n)
    x = np.tanh(1.4 * x) * env_adsr(n, 0.005, 0.12, 0.7, min(0.08, dur * 0.3))
    return level * lp(x, 900) * 0.8


def pluck(m, level=1.0, dur=0.5):
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = midi(m)
    x = np.zeros(n)
    for k in range(1, 8):
        x += np.sin(2 * np.pi * f * k * t + rng.uniform(0, 6.28)) / k * np.exp(-t * (6 + 5 * k))
    return level * x * 0.35


def chime(m, level=1.0):
    n = int(1.6 * SR)
    t = np.arange(n) / SR
    f = midi(m)
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.55) + 0.45 * np.sin(2 * np.pi * f * 2.0 * t) * np.exp(-t / 0.3)
         + 0.2 * np.sin(2 * np.pi * f * 3.01 * t) * np.exp(-t / 0.18))
    x *= np.minimum(1, t / 0.003)
    return level * x * 0.3


def whoosh(dur=0.7, level=1.0, rise=True):
    n = int(dur * SR)
    t = np.linspace(0, 1, n)
    x = rng.standard_normal(n)
    out = np.zeros(n)
    seg = 8
    for i in range(seg):  # sweeping band-pass
        a, b = i * n // seg, (i + 1) * n // seg
        c = 400 + 5000 * ((i + 0.5) / seg if rise else 1 - (i + 0.5) / seg)
        out[a:b] = bp(x[a:b], c * 0.6, min(c * 1.6, 20000))
    e = np.sin(np.pi * t) ** 2 if not rise else t ** 2.2
    return level * out * e * 0.5


def thud(level=1.0):
    n = int(0.6 * SR)
    t = np.arange(n) / SR
    f = 38 + 60 * np.exp(-t / 0.05)
    body = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.16)
    card = lp(rng.standard_normal(n), 1800) * np.exp(-t / 0.05) * 0.6
    return level * np.tanh(2 * (body + card)) * 0.8


def reverb_ir(seconds=2.6, predelay=0.018):
    n = int(seconds * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal((2, n)) * np.exp(-t / (seconds / 6.9))
    ir = np.stack([lp(ir[0], 6000), lp(ir[1], 6000)])
    pd = np.zeros((2, int(predelay * SR)))
    ir = np.concatenate([pd, ir], axis=1)
    return ir / np.sqrt((ir ** 2).sum(axis=1, keepdims=True))


# ------------------------------------------------------------------ arrangement
def build():
    pad = np.zeros(N); bass = np.zeros(N); drums = np.zeros(N); keys = np.zeros(N); fx = np.zeros(N)
    # D minor: Dm9 | Bbmaj9 | Fadd9/A | Csus2   (one chord per bar = 4 beats = one product cut)
    prog = [([50, 57, 60, 64, 65], 38), ([46, 53, 57, 60, 62], 34), ([45, 53, 57, 60, 67], 33), ([48, 55, 60, 62, 67], 36)]
    total_beats = int(DUR / BEAT) + 1
    end_hit = 94   # end-card cut (frame 1317)
    for bar in range(0, total_beats // 4 + 1):
        b0 = bar * 4
        notes, root = prog[bar % 4]
        if b0 >= end_hit:
            break
        cutoff = 900 if b0 < 14 else (1600 if b0 < 24 else 2300)
        place(pad, pad_chord(notes, 4 * BEAT + 0.6, cutoff), b2t(b0), 0.55)
        # bass from the browse section on
        if b0 >= 12 and not (68 <= b0 < 76):
            pattern = [(0, 1.5), (1.5, 0.5), (2, 1.0), (3.5, 0.5)] if b0 >= 24 else [(0, 2.0), (2, 2.0)]
            for off, d in pattern:
                place(bass, bass_note(root - 12 if off == 0 else root, d * BEAT * 0.95), b2t(b0 + off), 0.7)
        # arpeggio
        if 14 <= b0 < 94 and not (68 <= b0 < 72):
            arp = sorted(notes[1:]) + [notes[1] + 12]
            for i in range(8):
                place(keys, pluck(arp[(i * 3) % len(arp)] + 12, 0.5 if b0 < 24 else 0.7), b2t(b0 + i * 0.5), 1.0)
    # drums
    for b in range(total_beats):
        t0 = b2t(b)
        if 14 <= b < 94 and not (68 <= b < 74):
            place(drums, kick(0.95 if b >= 24 else 0.7), t0)
        if (24 <= b < 48 or 76 <= b < 94) and b % 2 == 1:
            place(drums, snap(0.8), t0)
        if 18 <= b < 94 and not (68 <= b < 74):
            for s16 in range(4 if b >= 24 else 2):
                v = (0.55 if s16 % 2 == 0 else 0.32) * rng.uniform(0.85, 1.1)
                place(drums, hat(v, open_=(s16 == 2 and b % 4 == 3)), t0 + s16 * BEAT / (4 if b >= 24 else 2))
    # sidechain pump on pad + bass
    duck = np.ones(N)
    for b in range(14, 94):
        if 68 <= b < 74:
            continue
        i0 = int(b2t(b) * SR)
        n = min(int(0.35 * SR), N - i0)
        if n > 0:
            duck[i0:i0 + n] = np.minimum(duck[i0:i0 + n], 1 - 0.38 * np.exp(-np.arange(n) / SR / 0.11))
    pad *= duck
    bass *= duck
    # FX / sound design on picture
    place(fx, whoosh(1.4, 0.35, rise=True), b2t(14) - 1.4)       # into browse
    place(fx, whoosh(1.9, 0.45, rise=True), b2t(24) - 1.9)       # into product montage
    for b in (28, 32, 36, 40, 44):
        place(fx, whoosh(0.5, 0.18, rise=False), b2t(b) - 0.18)
    place(fx, chime(79, 0.6), f2t(758))                           # added to cart
    place(fx, chime(83, 0.35), f2t(758) + 0.09)
    place(fx, chime(76, 0.5), f2t(878))                           # order confirmed
    place(fx, chime(81, 0.4), f2t(878) + 0.12)
    place(fx, chime(84, 0.3), f2t(878) + 0.24)
    place(fx, thud(1.0), f2t(967))                                # box lands
    place(fx, whoosh(2.2, 0.55, rise=True), b2t(end_hit) - 2.2)   # riser into end card
    # end hit: big chord + sub boom, long tail
    hit_t = b2t(end_hit)
    place(pad, pad_chord([38, 50, 57, 62, 64, 69], 6.0, 2600), hit_t, 0.9)
    place(bass, bass_note(26, 3.5, 1.0), hit_t)
    place(drums, kick(1.2), hit_t)
    place(fx, chime(86, 0.35), hit_t + 0.02)
    return pad, bass, drums, keys, fx


def mix():
    pad, bass, drums, keys, fx = build()
    L = 0.9 * pad + bass + drums + 0.8 * keys + fx
    R = L.copy()
    # stereo: offset pad + keys slightly, hats wider
    d = int(0.011 * SR)
    R[d:] = R[d:] * 0.5 + 0.5 * (0.9 * pad + 0.8 * keys)[:-d] + 0.5 * (bass + drums + fx)[d:]
    dry = np.stack([L, R])
    ir = reverb_ir()
    wet_src = np.stack([0.9 * pad + 0.9 * keys + 0.6 * fx + 0.15 * drums] * 2)
    wet = np.stack([signal.fftconvolve(wet_src[i], ir[i])[:N] for i in range(2)])
    out = dry + 0.32 * wet
    out = hp(out, 28)
    # gentle bus glue + soft clip, fades
    out = np.tanh(1.15 * out / np.max(np.abs(out)) * 1.4) / np.tanh(1.4 * 1.15)
    fade_in = np.minimum(1, t_all / 1.2)
    fade_out = np.clip((DUR - t_all) / 2.5, 0, 1)
    out *= fade_in * fade_out
    out *= 10 ** (-1.0 / 20) / np.max(np.abs(out))
    return out


def write(path, out):
    pcm = (np.clip(out.T, -1, 1) * 32767).astype('<i2')
    with wave.open(path, 'wb') as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


if __name__ == '__main__':
    o = mix()
    write(sys.argv[1] if len(sys.argv) > 1 else 'music.wav', o)
    rms = np.sqrt((o ** 2).mean())
    print('MUSIC_OK peak %.2f dBFS rms %.1f dBFS' % (20 * np.log10(np.abs(o).max()), 20 * np.log10(rms)))
