"""Assemble rendered frames + title cards + soundtrack into the final MP4 (ffmpeg).

python finish.py <frames_dir> <out.mp4> [music.wav]
"""
import os, sys, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
FPS = 24
TOTAL = 1440
FRAME_EXT = 'jpg'
TITLES = [  # (png, first frame, last frame)
    ('t_shop', 214, 330),
    ('t_watch', 345, 389), ('t_perfume', 401, 445), ('t_earbuds', 457, 501),
    ('t_sun', 513, 557), ('t_candle', 569, 613), ('t_serum', 625, 669),
    ('t_sellers', 690, 800),
    ('t_pay', 822, 876), ('t_track', 892, 950),
    ('t_courier', 1062, 1172),
    ('t_hero', 1188, 1312),
    ('t_end_word', 1360, 1440), ('t_end_tag', 1372, 1440), ('t_end_url', 1386, 1440),
]


def sec(f):
    return (f - 1) / FPS


def build_cmd(frames_dir, out, music=None, titles_dir=None, crf=16):
    titles_dir = titles_dir or os.path.join(HERE, 'titles')
    dur = TOTAL / FPS
    cmd = ['ffmpeg', '-y', '-framerate', str(FPS), '-start_number', '1',
           '-i', os.path.join(frames_dir, 'f_%04d.' + FRAME_EXT)]
    for name, _, _ in TITLES:
        cmd += ['-loop', '1', '-framerate', str(FPS), '-t', '%.3f' % dur, '-i', os.path.join(titles_dir, name + '.png')]
    if music:
        cmd += ['-i', music]
    fc = ['[0:v]scale=1920:1080:flags=lanczos,setpts=PTS-STARTPTS,format=rgb24[v0]']
    cur = 'v0'
    for i, (name, a, b) in enumerate(TITLES, start=1):
        t0, t1 = sec(a), sec(b + 1)
        fo = 0.5 if b >= TOTAL else 0.3
        fc.append('[%d:v]format=rgba,fade=t=in:st=%.3f:d=0.4:alpha=1,fade=t=out:st=%.3f:d=%.2f:alpha=1[t%d]'
                  % (i, t0, t1 - fo, fo, i))
        y = "'18*pow(max(0,1-(t-%.3f)/0.6),2)'" % t0
        fc.append("[%s][t%d]overlay=x=0:y=%s:enable='between(t,%.3f,%.3f)'[v%d]" % (cur, i, y, t0, t1, i))
        cur = 'v%d' % i
    fc.append('[%s]vignette=angle=PI/6,noise=c0s=3:c0f=t+u,format=yuv420p[vout]' % cur)
    cmd += ['-filter_complex', ';'.join(fc), '-map', '[vout]']
    if music:
        cmd += ['-map', '%d:a' % (len(TITLES) + 1), '-c:a', 'aac', '-b:a', '256k']
    cmd += ['-c:v', 'libx264', '-preset', 'medium', '-crf', str(crf), '-profile:v', 'high', '-pix_fmt', 'yuv420p',
            '-r', str(FPS), '-t', '%.3f' % dur, '-movflags', '+faststart', out]
    return cmd


if __name__ == '__main__':
    frames, out = sys.argv[1], sys.argv[2]
    music = sys.argv[3] if len(sys.argv) > 3 else None
    cmd = build_cmd(frames, out, music)
    print(' '.join(cmd[:8]), '...')
    subprocess.run(cmd, check=True)
    print('VIDEO_OK', out, os.path.getsize(out) // 1024, 'KB')
