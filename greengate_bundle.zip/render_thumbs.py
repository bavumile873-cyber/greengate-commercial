"""Render e-commerce listing photos (white background, soft contact shadow).

blender -b --factory-startup --python render_thumbs.py -- [size] [samples] [only_key]
"""
import bpy, sys, os, math
import numpy as np
from mathutils import Vector
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gg_lib as G

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
SIZE = int(argv[0]) if len(argv) > 0 else 800
SAMPLES = int(argv[1]) if len(argv) > 1 else 96
ONLY = argv[2] if len(argv) > 2 else None
OUT = os.path.join(G.ASSET_DIR, 'thumbs')
os.makedirs(OUT, exist_ok=True)


def recolor(name, hexcol):
    m = bpy.data.materials.get(name)
    if m:
        inp = G.bsdf(m).inputs['Base Color']
        if inp.is_linked and inp.links[0].from_node.bl_idname == 'ShaderNodeMix':
            inp.links[0].from_node.inputs[6].default_value = G.hexc(hexcol)
        else:
            inp.default_value = G.hexc(hexcol)


PRODUCTS = [
    # key, builder, azimuth deg, elevation deg, zoom, tweak
    ('watch', G.build_watch, -28, 9, 1.0, None),
    ('perfume', G.build_perfume, -24, 8, 1.05, None),
    ('earbuds', G.build_earbuds_case, -30, 12, 1.15, None),
    ('sunglasses', G.build_sunglasses, -32, 16, 1.0, None),
    ('candle', G.build_candle, -20, 14, 1.05, None),
    ('serum', G.build_serum, -18, 8, 1.1, None),
    ('lipstick', G.build_lipstick, -35, 14, 1.0, None),
    ('lipstick_nude', G.build_lipstick, -35, 14, 1.0, lambda: recolor('Lipstick_Red', '#b0655a')),
    ('watch_black', G.build_watch, -28, 9, 1.0, lambda: (recolor('Dial_Green_Sunburst', '#101214'),
                                                        recolor('Leather_Black', '#5a3720'))),
]


def bbox_of(root):
    dg = bpy.context.evaluated_depsgraph_get()
    pts = []
    for o in [root] + list(root.children_recursive):
        if o.type in ('MESH', 'CURVE'):
            ev = o.evaluated_get(dg)
            pts += [ev.matrix_world @ Vector(c) for c in ev.bound_box]
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return lo, hi


def shoot(key, builder, az, el, zoom, tweak):
    G.clear_scene()
    sc = bpy.context.scene
    G.setup_render(sc, (SIZE, SIZE), SAMPLES)
    sc.render.film_transparent = True
    sc.view_settings.exposure = 0.0
    G.world_studio(sc, color=(1, 1, 1), strength=0.25)
    root = builder()
    if tweak:
        tweak()
    bpy.context.view_layer.update()
    lo, hi = bbox_of(root)
    c = (lo + hi) / 2
    size = max(hi - lo)
    floor = G.plane_obj('Floor', 4, 4, None, plane='XY')
    floor.location.z = lo.z
    floor.is_shadow_catcher = True
    lens = 85
    fov = 2 * math.atan(18 / lens)
    dist = (size * 0.5 / math.tan(fov / 2)) * 1.55 / zoom
    a, e = math.radians(az), math.radians(el)
    camloc = c + Vector((math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e))) * dist
    G.camera('Cam', camloc, c, lens=lens, fstop=None)
    sc.camera = bpy.data.objects['Cam']
    s = size
    G.area_light_irr('Key', c + Vector((-1.3, -1.2, 1.4)) * s * 3, c, (s * 5, s * 5), irradiance=3.4)
    G.area_light_irr('Fill', c + Vector((1.6, -0.8, 0.5)) * s * 3, c, (s * 4, s * 4), irradiance=1.2)
    G.area_light_irr('Top', c + Vector((0, 0.3, 2.0)) * s * 3, c, (s * 3, s * 3), irradiance=1.4)
    G.area_light_irr('Rim', c + Vector((0.4, 1.8, 0.9)) * s * 3, c, (s * 0.8, s * 3), irradiance=2.2)
    path = os.path.join(OUT, key + '_raw.png')
    sc.render.image_settings.file_format = 'PNG'
    sc.render.image_settings.color_mode = 'RGBA'
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)
    # composite over white (shadow catcher alpha -> soft grey shadow)
    img = bpy.data.images.load(path)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    a = px[..., 3:4]
    rgb = px[..., :3] * a + (1 - a) * 0.985
    out = np.concatenate([rgb, np.ones_like(a)], axis=2).astype(np.float32)
    img2 = bpy.data.images.new(key, w, h, alpha=False)
    img2.pixels.foreach_set(out.ravel())
    img2.filepath_raw = os.path.join(OUT, key + '.png')
    img2.file_format = 'PNG'
    img2.save()
    os.remove(path)
    print('THUMB', key, w, h)


for row in PRODUCTS:
    if ONLY and row[0] != ONLY:
        continue
    shoot(*row)
